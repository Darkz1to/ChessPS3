// Backend "nulo" para checar a logica do jogo no PC (sem GPU): compila o mesmo codigo de source/engine + source/game.
#include "platform/platform.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct plat::Texture { int w, h; };

namespace {
std::string base;
uint32_t clockMs = 0;
int frames = 0, maxFrames = 600;
unsigned long quads = 0, frameQuads = 0, maxFrameQuads = 0;
int texCount = 0;
}

namespace plat {
bool init(int argc, char** argv) {
    base = (argc > 1) ? argv[1] : "./";
    if (!base.empty() && base[base.size() - 1] != '/') base += '/';
    if (argc > 2) maxFrames = atoi(argv[2]);
    return true;
}
void shutdown() { printf("[host] frames=%d quads=%lu maxQuadsPerFrame=%lu texturas=%d\n", frames, quads, maxFrameQuads, texCount); }
bool pump() { return frames++ < maxFrames; }
uint32_t nowMs() { return clockMs += 17; }
const std::string& baseDir() { return base; }
bool readFile(const std::string& p, std::vector<uint8_t>& out) {
    FILE* f = fopen(p.c_str(), "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    out.resize((size_t)n);
    size_t got = n ? fread(&out[0], 1, (size_t)n, f) : 0;
    fclose(f);
    return got == (size_t)n;
}
Texture* createTexture(int w, int h, const uint8_t*) { texCount++; Texture* t = new Texture(); t->w = w; t->h = h; return t; }
void beginFrame(float, float, float) { frameQuads = 0; }
void draw(const Texture*, float, float, float, float, float, float, float, float, uint32_t, bool) { quads++; frameQuads++; }
void endFrame() { if (frameQuads > maxFrameQuads) maxFrameQuads = frameQuads; }
void readPad(PadState& p) {
    p = PadState(); p.connected = true;
    p.down = (frames < maxFrames / 2) ? PadState::RIGHT : (PadState::DOWN | PadState::SQUARE);
}
}
