// Mesmo loop do main.cpp, mas valida invariantes ao final.
#include "platform/platform.h"
#include "game/game.h"
#include <stdio.h>

int main(int argc, char** argv) {
    if (!plat::init(argc, argv)) return 1;
    Game g;
    g.init();
    float x0 = g.player.x, y0 = g.player.y;
    uint32_t last = plat::nowMs();
    while (plat::pump()) {
        uint32_t now = plat::nowMs(), dt = now - last; last = now;
        plat::PadState pad; plat::readPad(pad);
        g.update(dt, pad);
        g.draw();
    }
    char t[32]; g.clock.format(t, sizeof t);
    printf("[host] farmer (%.1f,%.1f) -> (%.1f,%.1f) facing=%d | relogio %s dia %d\n", x0, y0, g.player.x, g.player.y, g.player.facing, t, g.clock.dayOfMonth);
    plat::shutdown();
    bool moved = g.player.x != x0 || g.player.y != y0;
    bool inside = g.player.x >= 0 && g.player.y >= -128 && g.player.x <= g.widthPx() && g.player.y <= g.heightPx();
    if (!moved || !inside) { printf("[host] FALHOU: moved=%d inside=%d\n", moved, inside); return 2; }
    printf("[host] OK\n");
    return 0;
}
