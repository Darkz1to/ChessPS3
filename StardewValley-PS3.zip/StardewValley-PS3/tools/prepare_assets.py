#!/usr/bin/env python3
"""
Converte o Content do Stardew Valley (ja extraido com StardewXnbHack: PNG + TMX) para o formato do port PS3.

  python3 tools/prepare_assets.py <pasta Content extraida> <saida>/assets [--all-png]

Saida:
  *.tex   "STEX" | u32 w | u32 h | w*h*4 bytes (A,R,G,B)         (big-endian, direto pra GPU)
  *.smap  mapa: tamanho, tilesheets e camadas de gid (veja source/engine/content.cpp)
Copie a pasta 'assets' para  /dev_hdd0/game/STDW00001/USRDIR/assets/  (ou para pkgfiles/USRDIR/ antes do 'make pkg').
Os assets do jogo sao propriedade da ConcernedApe: use apenas a sua copia legitima.
"""
import argparse, base64, gzip, os, struct, sys, zlib
import xml.etree.ElementTree as ET
from PIL import Image

GID_MASK = 0x1FFFFFFF
DEFAULT_PNG_DIRS = ["Characters/Farmer", "Maps", "TileSheets", "LooseSprites"]
MAX_TEX = 4096


def be32(v): return struct.pack(">I", v & 0xFFFFFFFF)
def be16(v): return struct.pack(">H", v)
def pstr(s): b = s.encode("utf-8"); return be16(len(b)) + b


def key_of(root, path):
    return os.path.splitext(os.path.relpath(path, root))[0].replace(os.sep, "/")


def write_tex(src_png, dst):
    if os.path.exists(dst):
        return True
    im = Image.open(src_png).convert("RGBA")
    if im.width > MAX_TEX or im.height > MAX_TEX:
        print(f"  ! {src_png}: {im.width}x{im.height} excede {MAX_TEX} (limite de textura linear do RSX) - ignorado")
        return False
    r, g, b, a = im.split()
    argb = Image.merge("RGBA", (a, r, g, b)).tobytes()
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    with open(dst, "wb") as f:
        f.write(b"STEX" + be32(im.width) + be32(im.height) + argb)
    return True


def decode_layer(data_el, count):
    enc = data_el.get("encoding")
    comp = data_el.get("compression")
    text = (data_el.text or "").strip()
    if enc == "csv":
        vals = [int(v) for v in text.replace("\n", "").split(",") if v.strip() != ""]
    elif enc == "base64":
        raw = base64.b64decode(text)
        if comp == "gzip": raw = gzip.decompress(raw)
        elif comp == "zlib": raw = zlib.decompress(raw)
        vals = list(struct.unpack("<%dI" % (len(raw) // 4), raw))
    else:  # xml <tile gid=.../>
        vals = [int(t.get("gid", "0")) for t in data_el.findall("tile")]
    if len(vals) != count:
        raise ValueError(f"camada com {len(vals)} celulas, esperado {count}")
    return [v & GID_MASK for v in vals]


def convert_tmx(root, tmx, out_dir):
    m = ET.parse(tmx).getroot()
    w, h = int(m.get("width")), int(m.get("height"))
    sheets = []
    for ts in m.findall("tileset"):
        img = ts.find("image")
        if img is None:
            continue
        src = os.path.normpath(os.path.join(os.path.dirname(tmx), img.get("source")))
        if not os.path.exists(src):
            alt = os.path.join(root, "Maps", os.path.basename(src))
            if os.path.exists(alt): src = alt
            else:
                print(f"  ! tilesheet ausente: {src}"); continue
        k = key_of(root, src)
        if not write_tex(src, os.path.join(out_dir, k + ".tex")):
            continue
        iw, ih = int(img.get("width")), int(img.get("height"))
        sheets.append((ts.get("name", k), int(ts.get("firstgid")), iw, ih,
                       int(ts.get("tilewidth", 16)), int(ts.get("tileheight", 16)),
                       int(ts.get("margin", 0)), int(ts.get("spacing", 0)), k))
    sheets.sort(key=lambda s: s[1])
    layers = []
    for ly in m.findall("layer"):
        layers.append((ly.get("name"), decode_layer(ly.find("data"), w * h)))

    blob = b"SMAP" + be32(1) + be32(w) + be32(h) + be32(len(sheets))
    for name, fg, iw, ih, tw, th, mg, sp, k in sheets:
        blob += pstr(name) + be32(fg) + be32(iw) + be32(ih) + be32(tw) + be32(th) + be32(mg) + be32(sp) + pstr(k)
    blob += be32(len(layers))
    for name, cells in layers:
        blob += pstr(name) + b"".join(be32(c) for c in cells)
    dst = os.path.join(out_dir, key_of(root, tmx) + ".smap")
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    with open(dst, "wb") as f:
        f.write(blob)
    print(f"  map  {key_of(root, tmx)}  {w}x{h}  sheets={len(sheets)} layers={[l[0] for l in layers]}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("content"); ap.add_argument("out")
    ap.add_argument("--all-png", action="store_true", help="converte todos os PNG (pode gerar GBs)")
    a = ap.parse_args()
    root = os.path.abspath(a.content)
    if not os.path.isdir(root):
        sys.exit(f"pasta nao encontrada: {root}")
    n = 0
    for dp, _, files in os.walk(root):
        rel = os.path.relpath(dp, root).replace(os.sep, "/")
        take_png = a.all_png or any(rel == d or rel.startswith(d + "/") for d in DEFAULT_PNG_DIRS)
        for f in sorted(files):
            p = os.path.join(dp, f)
            if f.lower().endswith(".png") and take_png:
                if write_tex(p, os.path.join(a.out, key_of(root, p) + ".tex")): n += 1
            elif f.lower().endswith(".tmx"):
                try: convert_tmx(root, p, a.out)
                except Exception as e: print(f"  ! {p}: {e}")
    print(f"{n} texturas convertidas -> {a.out}")


if __name__ == "__main__":
    main()
