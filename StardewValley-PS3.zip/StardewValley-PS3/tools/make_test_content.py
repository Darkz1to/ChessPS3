#!/usr/bin/env python3
"""Gera um 'Content' minusculo no formato do StardewXnbHack (TMX + PNG) so para testar o pipeline."""
import os, sys
from PIL import Image
out = sys.argv[1]
os.makedirs(out + "/Maps", exist_ok=True)
os.makedirs(out + "/Characters/Farmer", exist_ok=True)
sheet = Image.new("RGBA", (64, 32), (0, 0, 0, 0))
for i in range(8):
    for y in range(16):
        for x in range(16):
            sheet.putpixel(((i % 4) * 16 + x, (i // 4) * 16 + y), (30 * i, 200 - 20 * i, 80, 255))
sheet.save(out + "/Maps/spring_outdoorsTileSheet.png")
Image.new("RGBA", (96, 96), (200, 120, 60, 255)).save(out + "/Characters/Farmer/farmer_base.png")
W, H = 80, 50
back = [1 + ((x + y) % 4) for y in range(H) for x in range(W)]
bld = [0] * (W * H)
for x in range(W):
    bld[x] = 5; bld[(H - 1) * W + x] = 5
for y in range(H):
    bld[y * W] = 5; bld[y * W + W - 1] = 5
csv = lambda a: ",\n".join(",".join(map(str, a[r * W:(r + 1) * W])) for r in range(H))
open(out + "/Maps/Farm.tmx", "w").write(f'''<?xml version="1.0" encoding="UTF-8"?>
<map version="1.0" orientation="orthogonal" width="{W}" height="{H}" tilewidth="16" tileheight="16">
 <tileset firstgid="1" name="spring_outdoorsTileSheet" tilewidth="16" tileheight="16">
  <image source="spring_outdoorsTileSheet.png" width="64" height="32"/>
 </tileset>
 <layer name="Back" width="{W}" height="{H}"><data encoding="csv">
{csv(back)}
</data></layer>
 <layer name="Buildings" width="{W}" height="{H}"><data encoding="csv">
{csv(bld)}
</data></layer>
</map>''')
