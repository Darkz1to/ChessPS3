#!/usr/bin/env bash
# Compila engine+game no PC com backend nulo e roda a logica (placeholder e, se houver python+PIL, com assets sinteticos).
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
g++ -std=gnu++14 -O1 -Wall -Wextra -Wno-unused-parameter -Isource \
    tools/host/host_main.cpp tools/host/host_platform.cpp \
    source/engine/content.cpp source/game/game.cpp source/game/farmer.cpp source/game/font.cpp \
    -o "$OUT/host_check"
echo "== mundo placeholder (sem assets)"
"$OUT/host_check" "$OUT/empty" 600
if python3 -c "import PIL" 2>/dev/null; then
    echo "== assets sinteticos (TMX -> .smap/.tex)"
    python3 tools/make_test_content.py "$OUT/content"
    python3 tools/prepare_assets.py "$OUT/content" "$OUT/pkg/assets"
    "$OUT/host_check" "$OUT/pkg" 600
else
    echo "(PIL ausente: pulando teste com assets)"
fi
rm -rf "$OUT"
