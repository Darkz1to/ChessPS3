#include "platform/platform.h"
#include "game/game.h"

int main(int argc, char** argv) {
    if (!plat::init(argc, argv)) return 1;

    Game game;
    game.init();

    uint32_t last = plat::nowMs();
    while (plat::pump()) {
        uint32_t now = plat::nowMs();
        uint32_t dt = now - last;
        last = now;
        if (dt > 50) dt = 50;            // evita saltos apos travadas

        plat::PadState pad;
        plat::readPad(pad);

        game.update(dt, pad);
        game.draw();
    }
    plat::shutdown();
    return 0;
}
