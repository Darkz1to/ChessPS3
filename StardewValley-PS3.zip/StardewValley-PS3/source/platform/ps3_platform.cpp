// Backend PS3: RSX (sprite batch), ioPad, sysutil.  Baseado nos samples do PSL1GHT (rsxtest / debugfont).
#include "platform/platform.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>
#include <math.h>
#include <ppu-types.h>

#include <sys/process.h>
#include <sys/systime.h>
#include <io/pad.h>
#include <rsx/rsx.h>
#include <sysutil/sysutil.h>
#include <sysutil/video.h>

#include "sprite_vpo.h"
#include "sprite_fpo.h"

SYS_PROCESS_PARAM(1001, 0x100000);

struct plat::Texture {
    u32 w, h, pitch, offset;
    void* mem;
};

namespace {

const u32 CB_SIZE          = 0x80000;            // command buffer 512 KB
const u32 HOST_SIZE        = 32 * 1024 * 1024;   // area IO mapeada (o resto da RAM fica pro jogo)
const u32 FB_COUNT         = 2;
const u32 LABEL_INDEX      = 255;
const u32 MAX_QUADS        = 16384;
const u32 VERTS_PER_QUAD   = 6;

struct Vtx { float x, y, z, w; float u, v; float r, g, b, a; };   // 40 bytes

gcmContextData* ctx = NULL;
videoResolution vres;
u32 dispW = 0, dispH = 0;
u32 colorPitch, depthPitch, depthOffset;
u32 colorOffset[FB_COUNT];
u32* colorBuf[FB_COUNT];
u32* depthBuf;
u32 curFb = 0;
bool firstFlip = true;
u32 labelVal = 1;
bool running = true;

// shaders
rsxVertexProgram*   vpo = (rsxVertexProgram*)sprite_vpo;
rsxFragmentProgram* fpo = (rsxFragmentProgram*)sprite_fpo;
void* vpUcode = NULL;
void* fpUcode = NULL;
u32   fpOffset = 0;
rsxProgramAttrib* aPos; rsxProgramAttrib* aCol; rsxProgramAttrib* aTex; rsxProgramAttrib* aSampler;

// vertex buffers (2 frames em voo)
Vtx*  vbuf[2];
u32   vboff[2];
u32   vcur = 0;
u32   vcount = 0;       // vertices escritos no frame
u32   vflushed = 0;     // vertices ja enviados ao draw
const plat::Texture* curTex = NULL;

std::string base;
padInfo pinfo;
padData pdata;

void waitFinish() {
    rsxSetWriteBackendLabel(ctx, LABEL_INDEX, labelVal);
    rsxFlushBuffer(ctx);
    while (*(vu32*)gcmGetLabelAddress(LABEL_INDEX) != labelVal) usleep(30);
    ++labelVal;
}
void waitRSXIdle() {
    rsxSetWriteBackendLabel(ctx, LABEL_INDEX, labelVal);
    rsxSetWaitLabel(ctx, LABEL_INDEX, labelVal);
    ++labelVal;
    waitFinish();
}

bool initVideo() {
    static const u32 ids[] = { VIDEO_RESOLUTION_720, VIDEO_RESOLUTION_1080, VIDEO_RESOLUTION_576, VIDEO_RESOLUTION_480 };
    s32 rval = -1; s32 resId = 0;
    for (size_t i = 0; i < sizeof(ids) / sizeof(ids[0]); i++) {
        if (videoGetResolutionAvailability(VIDEO_PRIMARY, ids[i], VIDEO_ASPECT_AUTO, 0) != 1) continue;
        resId = ids[i];
        rval = videoGetResolution(resId, &vres);
        if (!rval) break;
    }
    if (rval) { printf("sem resolucao de video utilizavel\n"); return false; }

    videoConfiguration cfg = { (u8)resId, VIDEO_BUFFER_FORMAT_XRGB, VIDEO_ASPECT_AUTO, {0,0,0,0,0,0,0,0,0}, (u32)vres.width * 4 };
    if (videoConfigure(VIDEO_PRIMARY, &cfg, NULL, 0)) { printf("videoConfigure falhou\n"); return false; }
    videoState st;
    videoGetState(VIDEO_PRIMARY, 0, &st);
    dispW = vres.width; dispH = vres.height;
    return true;
}

void setRenderTarget(u32 index) {
    gcmSurface sf;
    sf.colorFormat = GCM_SURFACE_X8R8G8B8;
    sf.colorTarget = GCM_SURFACE_TARGET_0;
    sf.colorLocation[0] = GCM_LOCATION_RSX;
    sf.colorOffset[0] = colorOffset[index];
    sf.colorPitch[0] = colorPitch;
    sf.colorLocation[1] = sf.colorLocation[2] = sf.colorLocation[3] = GCM_LOCATION_RSX;
    sf.colorOffset[1] = sf.colorOffset[2] = sf.colorOffset[3] = 0;
    sf.colorPitch[1] = sf.colorPitch[2] = sf.colorPitch[3] = 64;
    sf.depthFormat = GCM_SURFACE_ZETA_Z24S8;
    sf.depthLocation = GCM_LOCATION_RSX;
    sf.depthOffset = depthOffset;
    sf.depthPitch = depthPitch;
    sf.type = GCM_SURFACE_TYPE_LINEAR;
    sf.antiAlias = GCM_SURFACE_CENTER_1;
    sf.width = dispW; sf.height = dispH; sf.x = 0; sf.y = 0;
    rsxSetSurface(ctx, &sf);
}

void setDrawEnv() {
    rsxSetColorMask(ctx, GCM_COLOR_MASK_B | GCM_COLOR_MASK_G | GCM_COLOR_MASK_R | GCM_COLOR_MASK_A);
    rsxSetColorMaskMrt(ctx, 0);
    f32 scale[4]  = { dispW * 0.5f, dispH * -0.5f, 0.5f, 0.0f };
    f32 offset[4] = { dispW * 0.5f, dispH *  0.5f, 0.5f, 0.0f };
    rsxSetViewport(ctx, 0, 0, dispW, dispH, 0.0f, 1.0f, scale, offset);
    rsxSetScissor(ctx, 0, 0, dispW, dispH);
    rsxSetDepthTestEnable(ctx, GCM_FALSE);
    rsxSetDepthWriteEnable(ctx, GCM_FALSE);
    rsxSetShadeModel(ctx, GCM_SHADE_MODEL_SMOOTH);
    rsxSetFrontFace(ctx, GCM_FRONTFACE_CCW);
}

void flipFrame() {
    if (!firstFlip) { while (gcmGetFlipStatus() != 0) usleep(200); }
    gcmResetFlipStatus();
    gcmSetFlip(ctx, curFb);
    rsxFlushBuffer(ctx);
    gcmSetWaitFlip(ctx);
    curFb ^= 1;
    setRenderTarget(curFb);
    firstFlip = false;
}

void sysutilCb(u64 status, u64, void*) {
    if (status == SYSUTIL_EXIT_GAME) running = false;
}

void atExitCb() {
    if (ctx) { gcmSetWaitFlip(ctx); rsxFinish(ctx, 1); }
}

void bindAttribs() {
    rsxBindVertexArrayAttrib(ctx, aPos->index, 0, vboff[vcur] + 0,  sizeof(Vtx), 4, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    rsxBindVertexArrayAttrib(ctx, aTex->index, 0, vboff[vcur] + 16, sizeof(Vtx), 2, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    rsxBindVertexArrayAttrib(ctx, aCol->index, 0, vboff[vcur] + 24, sizeof(Vtx), 4, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
}

void setTexture(const plat::Texture* t) {
    gcmTexture tex;
    rsxInvalidateTextureCache(ctx, GCM_INVALIDATE_TEXTURE);
    tex.format    = GCM_TEXTURE_FORMAT_A8R8G8B8 | GCM_TEXTURE_FORMAT_LIN;
    tex.mipmap    = 1;
    tex.dimension = GCM_TEXTURE_DIMS_2D;
    tex.cubemap   = GCM_FALSE;
    tex.remap     = ((GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_B_SHIFT) |
                     (GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_G_SHIFT) |
                     (GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_R_SHIFT) |
                     (GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_A_SHIFT) |
                     (GCM_TEXTURE_REMAP_COLOR_B << GCM_TEXTURE_REMAP_COLOR_B_SHIFT) |
                     (GCM_TEXTURE_REMAP_COLOR_G << GCM_TEXTURE_REMAP_COLOR_G_SHIFT) |
                     (GCM_TEXTURE_REMAP_COLOR_R << GCM_TEXTURE_REMAP_COLOR_R_SHIFT) |
                     (GCM_TEXTURE_REMAP_COLOR_A << GCM_TEXTURE_REMAP_COLOR_A_SHIFT));
    tex.width = t->w; tex.height = t->h; tex.depth = 1;
    tex.location = GCM_LOCATION_RSX;
    tex.pitch = t->pitch;
    tex.offset = t->offset;
    rsxLoadTexture(ctx, aSampler->index, &tex);
    rsxTextureControl(ctx, aSampler->index, GCM_TRUE, 0 << 8, 12 << 8, GCM_TEXTURE_MAX_ANISO_1);
    // pixel art: sem filtro
    rsxTextureFilter(ctx, aSampler->index, 0, GCM_TEXTURE_NEAREST, GCM_TEXTURE_NEAREST, GCM_TEXTURE_CONVOLUTION_QUINCUNX);
    rsxTextureWrapMode(ctx, aSampler->index, GCM_TEXTURE_CLAMP_TO_EDGE, GCM_TEXTURE_CLAMP_TO_EDGE,
                       GCM_TEXTURE_CLAMP_TO_EDGE, 0, GCM_TEXTURE_ZFUNC_LESS, 0);
}

void flushBatch() {
    if (vcount == vflushed || !curTex) return;
    setTexture(curTex);
    rsxDrawVertexArray(ctx, GCM_TYPE_TRIANGLES, vflushed, vcount - vflushed);
    vflushed = vcount;
}

} // namespace

namespace plat {

bool init(int argc, char** argv) {
    // pasta base = diretorio do EBOOT.BIN
    base = "/dev_hdd0/game/STDW00001/USRDIR/";
    if (argc > 0 && argv && argv[0]) {
        std::string a = argv[0];
        size_t p = a.find_last_of('/');
        if (p != std::string::npos && a.compare(0, 5, "/dev_") == 0) base = a.substr(0, p + 1);
    }

    void* host = memalign(1024 * 1024, HOST_SIZE);
    if (!host) return false;
    rsxInit(&ctx, CB_SIZE, HOST_SIZE, host);
    if (!ctx) return false;
    if (!initVideo()) return false;
    waitRSXIdle();
    gcmSetFlipMode(GCM_FLIP_VSYNC);

    colorPitch = dispW * 4;
    depthPitch = dispW * 4;
    for (u32 i = 0; i < FB_COUNT; i++) {
        colorBuf[i] = (u32*)rsxMemalign(64, dispH * colorPitch);
        rsxAddressToOffset(colorBuf[i], &colorOffset[i]);
        gcmSetDisplayBuffer(i, colorOffset[i], colorPitch, dispW, dispH);
    }
    depthBuf = (u32*)rsxMemalign(64, dispH * depthPitch);
    rsxAddressToOffset(depthBuf, &depthOffset);

    // shaders
    u32 fpSize = 0, vpSize = 0;
    rsxVertexProgramGetUCode(vpo, &vpUcode, &vpSize);
    rsxFragmentProgramGetUCode(fpo, &fpUcode, &fpSize);
    void* fpBuf = rsxMemalign(64, fpSize);
    memcpy(fpBuf, fpUcode, fpSize);
    rsxAddressToOffset(fpBuf, &fpOffset);
    aPos = rsxVertexProgramGetAttrib(vpo, "position");
    aCol = rsxVertexProgramGetAttrib(vpo, "color");
    aTex = rsxVertexProgramGetAttrib(vpo, "texcoord");
    aSampler = rsxFragmentProgramGetAttrib(fpo, "texture");

    for (int i = 0; i < 2; i++) {
        vbuf[i] = (Vtx*)rsxMemalign(128, MAX_QUADS * VERTS_PER_QUAD * sizeof(Vtx));
        if (!vbuf[i]) return false;
        rsxAddressToOffset(vbuf[i], &vboff[i]);
    }

    ioPadInit(7);
    atexit(atExitCb);
    sysUtilRegisterCallback(0, sysutilCb, NULL);

    setDrawEnv();
    setRenderTarget(curFb);
    return true;
}

void shutdown() { atExitCb(); }

bool pump() {
    sysUtilCheckCallback();
    return running;
}

uint32_t nowMs() {
    u64 sec = 0, nsec = 0;
    sysGetCurrentTime(&sec, &nsec);
    return (uint32_t)(sec * 1000ull + nsec / 1000000ull);
}

const std::string& baseDir() { return base; }

bool readFile(const std::string& path, std::vector<uint8_t>& out) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (n < 0) { fclose(f); return false; }
    out.resize((size_t)n);
    size_t got = n ? fread(&out[0], 1, (size_t)n, f) : 0;
    fclose(f);
    return got == (size_t)n;
}

Texture* createTexture(int w, int h, const uint8_t* argb) {
    u32 pitch = ((u32)w * 4 + 63) & ~63u;
    void* mem = rsxMemalign(128, pitch * (u32)h);
    if (!mem) { printf("sem VRAM para textura %dx%d\n", w, h); return NULL; }
    for (int y = 0; y < h; y++)
        memcpy((u8*)mem + (size_t)y * pitch, argb + (size_t)y * w * 4, (size_t)w * 4);
    Texture* t = new Texture();
    t->w = w; t->h = h; t->pitch = pitch; t->mem = mem;
    rsxAddressToOffset(mem, &t->offset);
    return t;
}

void beginFrame(float r, float g, float b) {
    setDrawEnv();
    u32 argb = (0xFFu << 24) | ((u32)(r * 255) << 16) | ((u32)(g * 255) << 8) | (u32)(b * 255);
    rsxSetClearColor(ctx, argb);
    rsxSetClearDepthStencil(ctx, 0xffffff00);
    rsxClearSurface(ctx, GCM_CLEAR_R | GCM_CLEAR_G | GCM_CLEAR_B | GCM_CLEAR_A | GCM_CLEAR_S | GCM_CLEAR_Z);
    rsxSetZMinMaxControl(ctx, GCM_FALSE, GCM_TRUE, GCM_FALSE);
    for (int i = 0; i < 8; i++) rsxSetViewportClip(ctx, i, dispW, dispH);

    rsxSetBlendFunc(ctx, GCM_SRC_ALPHA, GCM_ONE_MINUS_SRC_ALPHA, GCM_SRC_ALPHA, GCM_ONE_MINUS_SRC_ALPHA);
    rsxSetBlendEquation(ctx, GCM_FUNC_ADD, GCM_FUNC_ADD);
    rsxSetBlendEnable(ctx, GCM_TRUE);
    rsxSetLogicOpEnable(ctx, GCM_FALSE);

    rsxLoadVertexProgram(ctx, vpo, vpUcode);
    rsxLoadFragmentProgramLocation(ctx, fpo, fpOffset, GCM_LOCATION_RSX);
    bindAttribs();

    vcount = vflushed = 0;
    curTex = NULL;
}

void draw(const Texture* t, float sx, float sy, float sw, float sh,
          float dx, float dy, float dw, float dh, uint32_t rgba, bool flipX) {
    if (!t) return;
    if (t != curTex) { flushBatch(); curTex = t; }
    if (vcount + VERTS_PER_QUAD > MAX_QUADS * VERTS_PER_QUAD) return;   // estouro: descarta

    const float inset = 0.02f;
    float u0 = (sx + inset) / t->w, u1 = (sx + sw - inset) / t->w;
    float v0 = (sy + inset) / t->h, v1 = (sy + sh - inset) / t->h;
    if (flipX) { float tmp = u0; u0 = u1; u1 = tmp; }

    float x0 = dx / (kScreenW * 0.5f) - 1.0f,        x1 = (dx + dw) / (kScreenW * 0.5f) - 1.0f;
    float y0 = 1.0f - dy / (kScreenH * 0.5f),        y1 = 1.0f - (dy + dh) / (kScreenH * 0.5f);

    float cr = ((rgba >> 24) & 0xFF) / 255.0f, cg = ((rgba >> 16) & 0xFF) / 255.0f;
    float cb = ((rgba >> 8) & 0xFF) / 255.0f,  ca = (rgba & 0xFF) / 255.0f;

    Vtx* v = vbuf[vcur] + vcount;
    const Vtx q[6] = {
        { x0, y0, 0, 1, u0, v0, cr, cg, cb, ca }, { x1, y0, 0, 1, u1, v0, cr, cg, cb, ca }, { x0, y1, 0, 1, u0, v1, cr, cg, cb, ca },
        { x1, y0, 0, 1, u1, v0, cr, cg, cb, ca }, { x1, y1, 0, 1, u1, v1, cr, cg, cb, ca }, { x0, y1, 0, 1, u0, v1, cr, cg, cb, ca },
    };
    memcpy(v, q, sizeof(q));
    vcount += VERTS_PER_QUAD;
}

void endFrame() {
    flushBatch();
    flipFrame();
    vcur ^= 1;     // proximo frame escreve no outro buffer
}

void readPad(PadState& out) {
    out = PadState();
    ioPadGetInfo(&pinfo);
    for (int i = 0; i < MAX_PADS; i++) {
        if (!pinfo.status[i]) continue;
        ioPadGetData(i, &pdata);
        if (pdata.len <= 0) continue;
        out.connected = true;
        uint32_t d = 0;
        if (pdata.BTN_UP) d |= PadState::UP;       if (pdata.BTN_DOWN) d |= PadState::DOWN;
        if (pdata.BTN_LEFT) d |= PadState::LEFT;   if (pdata.BTN_RIGHT) d |= PadState::RIGHT;
        if (pdata.BTN_CROSS) d |= PadState::CROSS; if (pdata.BTN_CIRCLE) d |= PadState::CIRCLE;
        if (pdata.BTN_SQUARE) d |= PadState::SQUARE; if (pdata.BTN_TRIANGLE) d |= PadState::TRIANGLE;
        if (pdata.BTN_L1) d |= PadState::L1;       if (pdata.BTN_R1) d |= PadState::R1;
        if (pdata.BTN_L2) d |= PadState::L2;       if (pdata.BTN_R2) d |= PadState::R2;
        if (pdata.BTN_START) d |= PadState::START; if (pdata.BTN_SELECT) d |= PadState::SELECT;
        if (pdata.BTN_L3) d |= PadState::L3;       if (pdata.BTN_R3) d |= PadState::R3;
        out.down = d;
        out.lx = ((int)pdata.ANA_L_H - 128) / 128.0f;
        out.ly = ((int)pdata.ANA_L_V - 128) / 128.0f;
        out.rx = ((int)pdata.ANA_R_H - 128) / 128.0f;
        out.ry = ((int)pdata.ANA_R_V - 128) / 128.0f;
        return;
    }
}

} // namespace plat
