// Camada de plataforma: tudo que depende de hardware fica atras dessa interface.
// Implementacoes: platform/ps3_platform.cpp (RSX/pad) e tools/host/host_platform.cpp (checagem no PC).
#pragma once
#include <stdint.h>
#include <string>
#include <vector>

namespace plat {

constexpr int kScreenW = 1280;   // resolucao logica (= viewport padrao do Stardew 1.5.6)
constexpr int kScreenH = 720;

struct Texture;                  // opaco

struct PadState {
    enum : uint32_t {
        UP = 1, DOWN = 2, LEFT = 4, RIGHT = 8,
        CROSS = 16, CIRCLE = 32, SQUARE = 64, TRIANGLE = 128,
        L1 = 256, R1 = 512, L2 = 1024, R2 = 2048,
        START = 4096, SELECT = 8192, L3 = 16384, R3 = 32768
    };
    uint32_t down = 0;           // bitmask de botoes
    float lx = 0, ly = 0;        // analogico esquerdo  [-1,1], +y = baixo
    float rx = 0, ry = 0;        // analogico direito
    bool connected = false;
    bool held(uint32_t b) const { return (down & b) != 0; }
};

bool init(int argc, char** argv);
void shutdown();
bool pump();                                   // processa eventos do sistema; false = sair
uint32_t nowMs();
const std::string& baseDir();                  // pasta do EBOOT (USRDIR), termina com '/'
bool readFile(const std::string& path, std::vector<uint8_t>& out);

// pixels: bytes A,R,G,B por pixel (w*h*4), linha a linha
Texture* createTexture(int w, int h, const uint8_t* argb);

void beginFrame(float r, float g, float b);
// src em pixels da textura, dst em pixels logicos (1280x720). rgba = 0xRRGGBBAA
void draw(const Texture* t, float sx, float sy, float sw, float sh,
          float dx, float dy, float dw, float dh, uint32_t rgba, bool flipX = false);
void endFrame();

void readPad(PadState& out);

} // namespace plat
