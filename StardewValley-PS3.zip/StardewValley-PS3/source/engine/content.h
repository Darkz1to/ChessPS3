// Carregamento de assets no formato PS3 (.tex / .smap), gerados por tools/prepare_assets.py.
// Todos os inteiros nos arquivos sao big-endian (= endianness nativa do Cell), lidos byte a byte.
#pragma once
#include <stdint.h>
#include <string>
#include <vector>
#include "platform/platform.h"

namespace content {

struct Tex {
    plat::Texture* t = nullptr;
    int w = 0, h = 0;
};

// rel = caminho sem extensao dentro de assets/ (ex: "Characters/Farmer/farmer_base"). nullptr se ausente.
Tex* texture(const std::string& rel);
Tex* white();   // textura 2x2 branca (retangulos coloridos / overlays)

struct Sheet {
    uint32_t firstGid = 0;
    int imgW = 0, imgH = 0, tileW = 16, tileH = 16, margin = 0, spacing = 0, columns = 1;
    std::string path;
    Tex* tex = nullptr;
};
struct Layer {
    std::string name;
    std::vector<uint32_t> gid;   // w*h, 0 = vazio
};
struct Map {
    int w = 0, h = 0;            // em tiles
    std::vector<Sheet> sheets;   // ordenadas por firstGid
    std::vector<Layer> layers;
    bool valid() const { return w > 0 && h > 0; }
    const Layer* layer(const char* name) const;
    uint32_t gidAt(const Layer& l, int tx, int ty) const {
        return (tx < 0 || ty < 0 || tx >= w || ty >= h) ? 0u : l.gid[(size_t)ty * w + tx];
    }
};

bool parseMap(const std::vector<uint8_t>& data, Map& out);   // sem tocar na GPU (testavel no host)
bool loadMap(const std::string& rel, Map& out);              // parse + resolve texturas das sheets

constexpr int kZoom = 4;                 // Game1.pixelZoom
constexpr int kTile = 16 * kZoom;        // Game1.tileSize = 64

void drawLayer(const Map& m, const Layer& l, int camX, int camY);

} // namespace content
