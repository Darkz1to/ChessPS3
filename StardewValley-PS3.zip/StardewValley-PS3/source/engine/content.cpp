#include "engine/content.h"
#include <map>
#include <string.h>

namespace content {

namespace {
std::map<std::string, Tex*> cache;
Tex whiteTex;

struct Reader {
    const std::vector<uint8_t>& d;
    size_t p = 0;
    bool ok = true;
    explicit Reader(const std::vector<uint8_t>& v) : d(v) {}
    uint32_t u32() {
        if (p + 4 > d.size()) { ok = false; return 0; }
        uint32_t v = ((uint32_t)d[p] << 24) | ((uint32_t)d[p + 1] << 16) | ((uint32_t)d[p + 2] << 8) | d[p + 3];
        p += 4; return v;
    }
    uint32_t u16() {
        if (p + 2 > d.size()) { ok = false; return 0; }
        uint32_t v = ((uint32_t)d[p] << 8) | d[p + 1];
        p += 2; return v;
    }
    std::string str() {
        uint32_t n = u16();
        if (!ok || p + n > d.size()) { ok = false; return std::string(); }
        std::string s((const char*)&d[p], n);
        p += n; return s;
    }
};
} // namespace

Tex* texture(const std::string& rel) {
    auto it = cache.find(rel);
    if (it != cache.end()) return it->second;

    Tex* result = nullptr;
    std::vector<uint8_t> buf;
    if (plat::readFile(plat::baseDir() + "assets/" + rel + ".tex", buf) && buf.size() >= 12 && memcmp(&buf[0], "STEX", 4) == 0) {
        Reader r(buf); r.p = 4;
        uint32_t w = r.u32(), h = r.u32();
        if (r.ok && w > 0 && h > 0 && w <= 4096 && h <= 4096 && buf.size() >= 12 + (size_t)w * h * 4) {
            plat::Texture* t = plat::createTexture((int)w, (int)h, &buf[12]);
            if (t) { result = new Tex(); result->t = t; result->w = (int)w; result->h = (int)h; }
        }
    }
    cache[rel] = result;   // cacheia tambem a ausencia
    return result;
}

Tex* white() {
    if (!whiteTex.t) {
        static const uint8_t px[16] = { 255,255,255,255, 255,255,255,255, 255,255,255,255, 255,255,255,255 };
        whiteTex.t = plat::createTexture(2, 2, px);
        whiteTex.w = whiteTex.h = 2;
    }
    return &whiteTex;
}

const Layer* Map::layer(const char* name) const {
    for (size_t i = 0; i < layers.size(); i++) if (layers[i].name == name) return &layers[i];
    return nullptr;
}

bool parseMap(const std::vector<uint8_t>& data, Map& out) {
    if (data.size() < 16 || memcmp(&data[0], "SMAP", 4) != 0) return false;
    Reader r(data); r.p = 4;
    if (r.u32() != 1) return false;                       // versao
    out = Map();
    out.w = (int)r.u32(); out.h = (int)r.u32();
    uint32_t ns = r.u32();
    if (!r.ok || out.w <= 0 || out.h <= 0 || out.w > 1024 || out.h > 1024 || ns > 64) return false;
    for (uint32_t i = 0; i < ns; i++) {
        Sheet s;
        r.str();                                          // nome (informativo)
        s.firstGid = r.u32();
        s.imgW = (int)r.u32(); s.imgH = (int)r.u32();
        s.tileW = (int)r.u32(); s.tileH = (int)r.u32();
        s.margin = (int)r.u32(); s.spacing = (int)r.u32();
        s.path = r.str();
        if (!r.ok || s.tileW <= 0 || s.tileH <= 0) return false;
        s.columns = (s.imgW - 2 * s.margin + s.spacing) / (s.tileW + s.spacing);
        if (s.columns < 1) s.columns = 1;
        out.sheets.push_back(s);
    }
    uint32_t nl = r.u32();
    if (!r.ok || nl > 32) return false;
    size_t cells = (size_t)out.w * out.h;
    for (uint32_t i = 0; i < nl; i++) {
        Layer l;
        l.name = r.str();
        if (!r.ok || r.p + cells * 4 > data.size()) return false;
        l.gid.resize(cells);
        for (size_t c = 0; c < cells; c++) l.gid[c] = r.u32();
        out.layers.push_back(l);
    }
    return r.ok;
}

bool loadMap(const std::string& rel, Map& out) {
    std::vector<uint8_t> buf;
    if (!plat::readFile(plat::baseDir() + "assets/" + rel + ".smap", buf)) return false;
    if (!parseMap(buf, out)) return false;
    for (size_t i = 0; i < out.sheets.size(); i++) out.sheets[i].tex = texture(out.sheets[i].path);
    return true;
}

void drawLayer(const Map& m, const Layer& l, int camX, int camY) {
    int tx0 = camX / kTile, ty0 = camY / kTile;
    if (camX < 0) tx0 = -1;
    if (camY < 0) ty0 = -1;
    int tx1 = (camX + plat::kScreenW) / kTile + 1, ty1 = (camY + plat::kScreenH) / kTile + 1;
    if (tx0 < 0) tx0 = 0;
    if (ty0 < 0) ty0 = 0;
    if (tx1 >= m.w) tx1 = m.w - 1;
    if (ty1 >= m.h) ty1 = m.h - 1;

    const Sheet* last = nullptr;
    for (int ty = ty0; ty <= ty1; ty++) {
        for (int tx = tx0; tx <= tx1; tx++) {
            uint32_t gid = l.gid[(size_t)ty * m.w + tx];
            if (!gid) continue;
            const Sheet* s = last;
            if (!s || gid < s->firstGid || (&*s != &m.sheets.back() && gid >= (s + 1)->firstGid)) {
                s = nullptr;
                for (size_t i = m.sheets.size(); i-- > 0;) if (gid >= m.sheets[i].firstGid) { s = &m.sheets[i]; break; }
                last = s;
            }
            if (!s || !s->tex) continue;
            uint32_t local = gid - s->firstGid;
            int col = (int)(local % (uint32_t)s->columns), row = (int)(local / (uint32_t)s->columns);
            float sx = (float)(s->margin + col * (s->tileW + s->spacing));
            float sy = (float)(s->margin + row * (s->tileH + s->spacing));
            plat::draw(s->tex->t, sx, sy, (float)s->tileW, (float)s->tileH,
                       (float)(tx * kTile - camX), (float)(ty * kTile - camY),
                       (float)(s->tileW * kZoom), (float)(s->tileH * kZoom), 0xFFFFFFFFu);
        }
    }
}

} // namespace content
