#include "game/farmer.h"
#include "engine/content.h"
#include <math.h>

bool Farmer::free(float px, float py, const World& w) const {
    int l, t, r, b;
    box(px, py, l, t, r, b);
    if (l < 0 || t < 0 || r > w.widthPx() || b > w.heightPx()) return false;
    for (int ty = t / 64; ty <= (b - 1) / 64; ty++)
        for (int tx = l / 64; tx <= (r - 1) / 64; tx++)
            if (w.tileBlocked(tx, ty)) return false;
    return true;
}

void Farmer::update(float dtMs, const plat::PadState& pad, const World& w) {
    int dx = 0, dy = 0;
    if (pad.held(plat::PadState::LEFT))  dx -= 1;
    if (pad.held(plat::PadState::RIGHT)) dx += 1;
    if (pad.held(plat::PadState::UP))    dy -= 1;
    if (pad.held(plat::PadState::DOWN))  dy += 1;
    if (dx == 0 && dy == 0) {                      // analogico esquerdo -> 8 direcoes (deadzone)
        if (pad.lx < -0.3f) dx = -1; else if (pad.lx > 0.3f) dx = 1;
        if (pad.ly < -0.3f) dy = -1; else if (pad.ly > 0.3f) dy = 1;
    }
    speed = pad.held(plat::PadState::SQUARE) ? 5 : 2;      // Square = correr (Farmer.speed 5)

    moving = (dx != 0 || dy != 0);
    if (!moving) { animTimer = 0; animFrame = 0; return; }

    // facing: igual ao original, a ultima direcao "dominante" vence; na diagonal mantem se ainda valida
    if (dx != 0 && dy == 0) facing = dx > 0 ? 1 : 3;
    else if (dy != 0 && dx == 0) facing = dy > 0 ? 2 : 0;
    else if (!((facing == 1 && dx > 0) || (facing == 3 && dx < 0) || (facing == 0 && dy < 0) || (facing == 2 && dy > 0)))
        facing = dx > 0 ? 1 : 3;

    // Farmer.getMovementSpeed(): max(1, speed * 0.066 * ms); diagonal *= 0.7
    float d = (float)speed * 0.066f * dtMs;
    if (d < 1.0f) d = 1.0f;
    if (dx != 0 && dy != 0) d *= 0.7f;

    if (dx != 0 && free(x + dx * d, y, w)) x += dx * d;
    if (dy != 0 && free(x, y + dy * d, w)) y += dy * d;

    animTimer += dtMs * (speed > 2 ? 1.6f : 1.0f);
    if (animTimer >= 110.0f) { animTimer -= 110.0f; animFrame = (animFrame + 1) % 6; }
}

void Farmer::draw(int camX, int camY) const {
    float dx = x - camX, dy = y - camY;
    content::Tex* t = content::texture("Characters/Farmer/farmer_base");
    if (!t) {                                       // sem assets: retangulo
        content::Tex* wt = content::white();
        plat::draw(wt->t, 0, 0, 2, 2, dx + 8, dy + 32, 48, 96, 0xE0803CFFu);
        return;
    }
    int row = facing == 2 ? 0 : (facing == 0 ? 2 : 1);   // baixo / cima / lado (esquerda = direita espelhada)
    plat::draw(t->t, (float)(animFrame * 16), (float)(row * 32), 16, 32, dx, dy, 64, 128, 0xFFFFFFFFu, facing == 3);
}
