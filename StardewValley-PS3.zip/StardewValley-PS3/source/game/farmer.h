// Farmer - porte do movimento de StardewValley.Farmer (getMovementSpeed, GetBoundingBox) e animacao basica de FarmerSprite.
#pragma once
#include "platform/platform.h"

struct World {                       // o que o fazendeiro precisa do mapa
    virtual bool tileBlocked(int tx, int ty) const = 0;
    virtual int widthPx() const = 0;
    virtual int heightPx() const = 0;
    virtual ~World() {}
};

struct Farmer {
    float x = 0, y = 0;              // Farmer.Position: canto sup-esq do sprite 64x128 em pixels do mundo
    int facing = 2;                  // 0 cima, 1 direita, 2 baixo, 3 esquerda (igual ao original)
    int speed = 2;                   // Farmer.speed: 2 andando, 5 correndo
    bool moving = false;
    float animTimer = 0;
    int animFrame = 0;

    void setTile(int tx, int ty) { x = (float)(tx * 64); y = (float)(ty * 64 - 64); }
    // Farmer.GetBoundingBox(): (x+8, y+spriteHeight-32, 48, 32), spriteHeight = 32*4
    void box(float px, float py, int& l, int& t, int& r, int& b) const {
        l = (int)px + 8; t = (int)py + 128 - 32; r = l + 48; b = t + 32;
    }
    void update(float dtMs, const plat::PadState& pad, const World& w);
    void draw(int camX, int camY) const;
    float centerX() const { return x + 32; }
    float centerY() const { return y + 96; }

private:
    bool free(float px, float py, const World& w) const;
};
