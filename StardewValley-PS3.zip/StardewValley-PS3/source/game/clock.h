// Relogio do jogo - porte de Game1.gameTimeInterval / performTenMinuteClockUpdate (1.5.6).
#pragma once
#include <stdint.h>
#include <stdio.h>

struct GameClock {
    static const int kMsPerTenMinutes = 7000;   // Game1.realMilliSecondsPerGameTenMinutes
    int timeOfDay = 600;                        // Game1.timeOfDay (HHMM, 600 = 6:00 AM)
    int gameTimeInterval = 0;
    int dayOfMonth = 1;

    void update(int dtMs) {
        gameTimeInterval += dtMs;
        if (gameTimeInterval > kMsPerTenMinutes) {
            gameTimeInterval = 0;
            timeOfDay += 10;
            if (timeOfDay % 100 >= 60) timeOfDay += 40;
            if (timeOfDay >= 2600) { timeOfDay = 600; dayOfMonth = dayOfMonth % 28 + 1; }   // (sem desmaio/dormir ainda)
        }
    }
    // Game1.getStartingToGetDarkTime() = 1800 (primavera/verao)
    float darkness() const {
        const int start = 1800;
        if (timeOfDay < start) return 0.0f;
        float mins = (float)((timeOfDay / 100 - start / 100) * 60 + timeOfDay % 100) + gameTimeInterval / (float)kMsPerTenMinutes * 10.0f;
        float a = mins / 400.0f * 0.6f;    // aproximacao visual; o original interpola cor ambiente
        return a > 0.6f ? 0.6f : a;
    }
    void format(char* out, size_t n) const {
        int h = timeOfDay / 100, m = timeOfDay % 100;
        int dh = h % 12; if (dh == 0) dh = 12;
        snprintf(out, n, "%d:%02d %s", dh, m, (h % 24) < 12 ? "AM" : "PM");
    }
};
