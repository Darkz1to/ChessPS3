// Fonte bitmap 3x5 minima (HUD de debug: relogio / FPS). A fonte real do jogo (SpriteFont) entra na proxima sessao.
#pragma once
#include <stdint.h>
void drawText(const char* s, float x, float y, float scale, uint32_t rgba);
