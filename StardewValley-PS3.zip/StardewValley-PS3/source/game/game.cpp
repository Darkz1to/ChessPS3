#include "game/game.h"
#include "game/font.h"
#include <stdio.h>

using namespace content;

bool Game::init() {
    haveMap = loadMap("Maps/Farm", map);
    if (haveMap) {
        mapW = map.w; mapH = map.h;
        player.setTile(64, 15);              // ponto de chegada padrao da Farm (porta da casa)
    } else {
        printf("Maps/Farm.smap nao encontrado em %sassets/ - usando mundo placeholder\n", plat::baseDir().c_str());
        mapW = 60; mapH = 40;
        player.setTile(30, 20);
    }
    updateCamera();
    return true;
}

bool Game::tileBlocked(int tx, int ty) const {
    if (tx < 0 || ty < 0 || tx >= mapW || ty >= mapH) return true;
    if (haveMap) {
        const Layer* b = map.layer("Buildings");
        return b && map.gidAt(*b, tx, ty) != 0;      // sessao 1: tile na camada Buildings = solido
    }
    // placeholder: borda + "pedras"
    return tx == 0 || ty == 0 || tx == mapW - 1 || ty == mapH - 1 || ((tx % 7 == 3) && (ty % 5 == 2));
}

void Game::update(uint32_t dtMs, const plat::PadState& pad) {
    clock.update((int)dtMs);
    player.update((float)dtMs, pad, *this);
    updateCamera();

    fpsAcc += dtMs; fpsFrames++;
    if (fpsAcc >= 500) { fps = fpsFrames * 1000.0f / fpsAcc; fpsAcc = 0; fpsFrames = 0; }
}

void Game::updateCamera() {
    // Game1.viewport centrado no jogador, limitado ao mapa (clampToMapSize)
    int cx = (int)player.centerX() - plat::kScreenW / 2;
    int cy = (int)player.centerY() - plat::kScreenH / 2;
    int maxX = widthPx() - plat::kScreenW, maxY = heightPx() - plat::kScreenH;
    camX = maxX <= 0 ? maxX / 2 : (cx < 0 ? 0 : (cx > maxX ? maxX : cx));
    camY = maxY <= 0 ? maxY / 2 : (cy < 0 ? 0 : (cy > maxY ? maxY : cy));
}

void Game::drawPlaceholderWorld() {
    Tex* w = white();
    int tx0 = camX / 64, ty0 = camY / 64;
    for (int ty = ty0; ty <= ty0 + 12 && ty < mapH; ty++)
        for (int tx = tx0; tx <= tx0 + 20 && tx < mapW; tx++) {
            uint32_t c = ((tx + ty) & 1) ? 0x5FA64EFFu : 0x58994AFFu;
            if (tileBlocked(tx, ty)) c = 0x7A7A7AFFu;
            plat::draw(w->t, 0, 0, 2, 2, (float)(tx * 64 - camX), (float)(ty * 64 - camY), 64, 64, c);
        }
}

void Game::draw() {
    plat::beginFrame(0.05f, 0.05f, 0.08f);

    if (haveMap) {
        const char* below[] = { "Back", "Buildings" };
        for (size_t i = 0; i < 2; i++) if (const Layer* l = map.layer(below[i])) drawLayer(map, *l, camX, camY);
        player.draw(camX, camY);
        const char* above[] = { "Front", "AlwaysFront" };
        for (size_t i = 0; i < 2; i++) if (const Layer* l = map.layer(above[i])) drawLayer(map, *l, camX, camY);
    } else {
        drawPlaceholderWorld();
        player.draw(camX, camY);
    }

    // escurecer ao entardecer
    float dark = clock.darkness();
    if (dark > 0.0f) {
        uint32_t a = (uint32_t)(dark * 255.0f);
        plat::draw(white()->t, 0, 0, 2, 2, 0, 0, plat::kScreenW, plat::kScreenH, 0x0A0A32u << 8 | a);
    }

    // HUD
    char buf[32];
    clock.format(buf, sizeof(buf));
    drawText(buf, plat::kScreenW - 220.0f, 16, 6, 0xFFE070FFu);
    snprintf(buf, sizeof(buf), "FPS %d", (int)(fps + 0.5f));
    drawText(buf, 16, 16, 4, 0xFFFFFFFFu);

    plat::endFrame();
}
