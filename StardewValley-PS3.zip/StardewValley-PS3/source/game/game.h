// Game1 (versao PS3): loop de atualizacao/desenho, mapa atual, camera (viewport), relogio, HUD.
#pragma once
#include "platform/platform.h"
#include "engine/content.h"
#include "game/clock.h"
#include "game/farmer.h"

class Game : public World {
public:
    bool init();
    void update(uint32_t dtMs, const plat::PadState& pad);
    void draw();

    bool tileBlocked(int tx, int ty) const override;
    int widthPx() const override { return mapW * 64; }
    int heightPx() const override { return mapH * 64; }

    GameClock clock;
    Farmer player;

private:
    content::Map map;
    bool haveMap = false;
    int mapW = 60, mapH = 40;
    int camX = 0, camY = 0;       // Game1.viewport.X / Y
    float fps = 0; int fpsFrames = 0; uint32_t fpsAcc = 0;

    void updateCamera();
    void drawPlaceholderWorld();
};
