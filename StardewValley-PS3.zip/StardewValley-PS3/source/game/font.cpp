#include "game/font.h"
#include "engine/content.h"
#include <ctype.h>

namespace {
// 5 linhas x 3 bits (bit 2 = coluna esquerda)
struct Glyph { char c; uint8_t r[5]; };
const Glyph kGlyphs[] = {
    {'0',{7,5,5,5,7}}, {'1',{2,6,2,2,7}}, {'2',{7,1,7,4,7}}, {'3',{7,1,7,1,7}}, {'4',{5,5,7,1,1}},
    {'5',{7,4,7,1,7}}, {'6',{7,4,7,5,7}}, {'7',{7,1,1,1,1}}, {'8',{7,5,7,5,7}}, {'9',{7,5,7,1,7}},
    {':',{0,2,0,2,0}}, {'.',{0,0,0,0,2}}, {'A',{2,5,7,5,5}}, {'P',{7,5,7,4,4}}, {'M',{5,7,7,5,5}},
    {'F',{7,4,7,4,4}}, {'S',{7,4,7,1,7}}, {'D',{6,5,5,5,6}}, {'Y',{5,5,2,2,2}}, {'-',{0,0,7,0,0}},
};
const Glyph* find(char c) {
    c = (char)toupper((unsigned char)c);
    for (size_t i = 0; i < sizeof(kGlyphs) / sizeof(kGlyphs[0]); i++) if (kGlyphs[i].c == c) return &kGlyphs[i];
    return nullptr;
}
}

void drawText(const char* s, float x, float y, float scale, uint32_t rgba) {
    content::Tex* w = content::white();
    for (; *s; s++, x += 4 * scale) {
        const Glyph* g = find(*s);
        if (!g) continue;
        for (int row = 0; row < 5; row++)
            for (int col = 0; col < 3; col++)
                if (g->r[row] & (4 >> col))
                    plat::draw(w->t, 0, 0, 2, 2, x + col * scale, y + row * scale, scale, scale, rgba);
    }
}
