# Tutorial passo a passo: do código ao jogo rodando no PS3

## Requisitos
- PS3 com **CFW** (ou **HEN** em firmware 4.9x) para instalar PKGs homebrew. Em PS3 original sem isso, não roda.
- Uma conta no GitHub (gratuita).
- Sua cópia legítima do Stardew Valley no PC (Steam/GOG) para extrair os assets.
- Python 3 + Pillow no PC (`pip install pillow`).

---
## PARTE 1 - Compilar pelo GitHub (sem instalar nada)
1. Crie um repositório novo no GitHub (ex.: `StardewValley-PS3`), vazio.
2. Descompacte o zip e envie **todo** o conteúdo para o repositório.
   - Atenção: a pasta `.github/` é **oculta**. No Windows ative "Itens ocultos"; no Mac `Cmd+Shift+.`.
   - Se não conseguir enviar a pasta oculta: no GitHub clique **Add file → Create new file**, digite o nome
     `.github/workflows/build.yml` e cole o conteúdo de `GITHUB_WORKFLOW_build.yml` (que está visível no zip).
   - Via terminal: `git init && git add -A && git commit -m "port ps3" && git branch -M main && git remote add origin <URL> && git push -u origin main`
3. No GitHub abra a aba **Actions**. Se pedir, clique em *"I understand my workflows, enable them"*.
4. Escolha **Build PS3 (PKG + SELF)** → **Run workflow** (um push também dispara sozinho).
5. Aguarde ~3-6 min. Verde = ok. Clique na execução → role até **Artifacts** → baixe **StardewPS3** (zip com `StardewPS3.pkg` e `StardewPS3.self`).
6. Se ficar **vermelho**: abra o passo que falhou, copie o log e me mande; o código do PS3 ainda não foi compilado por mim.

## PARTE 2 - Preparar os assets (no PC)
1. Baixe o **StardewXnbHack** (github.com/Pathoschild/StardewXnbHack/releases), coloque na pasta do jogo e execute. Ele cria `Content (unpacked)` com PNG e TMX.
2. No repositório (pasta do projeto) rode:
   ```
   python3 tools/prepare_assets.py "C:\caminho\Content (unpacked)" saida/assets
   ```
   Isso gera `.tex` (texturas) e `.smap` (mapas). Aviso "excede 4096" em algum PNG = esse arquivo é ignorado (limite do RSX).
3. Confira se existem `saida/assets/Maps/Farm.smap` e `saida/assets/Characters/Farmer/farmer_base.tex`.

## PARTE 3 - Instalar no PS3
1. Copie `StardewPS3.pkg` para um pendrive (FAT32) na pasta `/PKG` (ou qualquer pasta) e ligue no PS3.
2. No XMB: **Game → Package Manager → Install Package Files → Standard** (ou *Install Package Files* do menu Game) → escolha o `.pkg`.
   - Com multiMAN/webMAN você também pode mandar o PKG por FTP para `/dev_hdd0/packages` e instalar de lá.
3. O jogo aparece em **Game → Stardew Valley PS3 (WIP)**.

## PARTE 4 - Colocar os assets no PS3
Escolha **uma** opção:
- **FTP (mais fácil):** com webMAN/multiMAN ligado, conecte um cliente FTP (FileZilla) ao IP do PS3, porta 21, usuário/senha qualquer.
  Envie a pasta `assets` para `/dev_hdd0/game/STDW00001/USRDIR/assets/`.
- **Pendrive:** use o gerenciador de arquivos do multiMAN (ou webMAN File Manager) para copiar `assets` para o mesmo caminho acima.
- **Dentro do PKG:** antes de compilar, coloque a pasta em `pkgfiles/USRDIR/assets/` (não suba para GitHub público: os assets são da ConcernedApe!) e gere o PKG localmente (Parte 6).

Resultado final: `/dev_hdd0/game/STDW00001/USRDIR/assets/Maps/Farm.smap` etc.

## PARTE 5 - Jogar
Abra o jogo no XMB. Controles: **D-pad/analógico** andar · **Quadrado** correr · **PS** sair.
Sem assets ou com caminho errado aparece um chão verde quadriculado com um boneco laranja (placeholder). Isso significa que o jogo roda e só falta achar os assets (confira o caminho da Parte 4).

## Testar no PC (RPCS3, opcional)
1. Instale o RPCS3, **File → Install Packages/Raps/Edats** → `StardewPS3.pkg`.
2. Copie `assets` para a pasta `dev_hdd0/game/STDW00001/USRDIR/assets/` dentro do diretório do RPCS3.
3. Inicie pelo jogo na lista. Útil para ver erros em *Logs*.

## PARTE 6 - Build local (alternativa ao GitHub)
Linux/WSL2 (Ubuntu):
```
sudo apt install -y libelf-dev zlib1g-dev libssl-dev python3 make g++ curl
# baixe ps3dev-linux-X64.tar.gz da release mais recente em github.com/ps3dev/ps3dev/releases
sudo tar xzf ps3dev-linux-X64.tar.gz -C /usr/local
export PS3DEV=/usr/local/ps3dev
./build.sh
```
Saída: `StardewPS3.self` e `StardewPS3.pkg` na raiz.

## Problemas comuns
| Sintoma | Causa provável |
|---|---|
| Actions falha em "Download ps3dev SDK" | Release sem `ps3dev-linux-X64.tar.gz`; me mande o log |
| PKG não instala | Firmware sem CFW/HEN ou PKG corrompido no download |
| Tela preta / volta pro XMB | Mande o log do RPCS3 (ou do PS3 via `ps3load`) |
| Placeholder verde em vez do jogo | Assets no caminho errado (Parte 4) |
