#!/usr/bin/env bash
# Build local (Linux/WSL/macOS) com o SDK ps3dev ja instalado. Gera StardewPS3.self e StardewPS3.pkg
set -euo pipefail
cd "$(dirname "$0")"
: "${PS3DEV:=/usr/local/ps3dev}"
export PS3DEV PSL1GHT="${PSL1GHT:-$PS3DEV}"
export PATH="$PATH:$PS3DEV/bin:$PS3DEV/ppu/bin:$PS3DEV/spu/bin"
[ -d "$PS3DEV" ] || { echo "ps3dev nao encontrado em $PS3DEV (veja TUTORIAL.md, secao 'Build local')"; exit 1; }
bash tools/host_check.sh      # opcional: teste de logica no PC
make clean
make pkg
ls -la StardewPS3.self StardewPS3.pkg
