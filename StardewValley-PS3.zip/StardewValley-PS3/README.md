# Stardew Valley PS3 (port nativo, WIP)

Port em **C++ / PSL1GHT** (SDK homebrew do PS3) usando o código C# decompilado do Stardew Valley 1.5.6 como **referência de regras e constantes**.

> O PS3 não roda .NET/XNA/MonoGame, então não existe "recompilar" o C# direto. O caminho viável é reescrever em C++ nativo,
> camada por camada, portando a lógica do original. Esta é a **sessão 1: fundação + primeiro jogável**.

## Build (GitHub)
1. Suba este repositório no GitHub.
2. **Actions → Build PS3 → Run workflow** (ou qualquer push). O CI baixa o SDK `ps3dev`, roda o check de lógica no host e faz `make pkg`.
3. Baixe o artefato **StardewPS3** (`.pkg` e `.self`).

Local: `export PS3DEV=/usr/local/ps3dev PSL1GHT=/usr/local/ps3dev && make pkg`.

## Assets (você precisa da sua cópia do jogo)
1. Extraia o `Content` com [StardewXnbHack](https://github.com/Pathoschild/StardewXnbHack) (gera PNG + TMX).
2. `python3 tools/prepare_assets.py <Content_extraido> out/assets` (requer `pip install pillow`).
3. Copie `out/assets` para `/dev_hdd0/game/STDW00001/USRDIR/assets/` via FTP, ou coloque em `pkgfiles/USRDIR/assets` antes do `make pkg`.

Sem assets o jogo abre com um mundo placeholder (prova que vídeo, input e colisão funcionam).

## Controles
D-pad / analógico esquerdo = andar · Quadrado = correr · PS = sair

## O que está portado (sessão 1)
| Módulo | Origem (C#) | Status |
|---|---|---|
| Vídeo RSX 720p, sprite batch, texturas | XNA SpriteBatch | ✔ |
| Input (pad) | InputState | ✔ básico |
| Mapas (TMX → `.smap`), camadas Back/Buildings/Front/AlwaysFront | xTile | ✔ sem tiles animados |
| Farmer: velocidade, diagonal 0.7, bounding box, colisão por tile | Farmer.cs | ✔ |
| Câmera (viewport clamp) | Game1.viewport | ✔ |
| Relógio (7000 ms / 10 min) e escurecer ao entardecer | Game1.cs | ✔ aprox. |

## Próximos passos (sessões seguintes)
Propriedades de tile (Water/Passable/Diggable), troca de mapas/warps, fonte e menus, inventário/ferramentas, plantações, NPCs/diálogo,
áudio (XWB → PCM + libaudio), save/load (XML → formato próprio), otimização de memória (256 MB RAM / 256 MB VRAM).

## Estrutura
```
source/platform  interface + backend PS3 (RSX, pad)
source/engine    carregador de assets (.tex/.smap), desenho de camadas
source/game      Game, Farmer, relógio, HUD
shaders          sprite.vcg / sprite.fcg
tools            prepare_assets.py, host_check.sh (teste da lógica no PC)
```
