# HK3DS no PS3 — tutorial

> **Aviso honesto:** o código compila e linka com o toolchain real do PS3 (PSL1GHT/ps3dev), mas **não foi testado
> num PS3 nem no RPCS3**. Espere ajustar coisas. Se algo falhar, o jogo escreve `save/log.txt` ao lado do `romfs`.

## Como funciona (resumo)
O jogo precisa de **duas coisas separadas**:

| Peça | Quem faz | Onde |
|---|---|---|
| **Programa** (`.pkg`) | GitHub Actions compila para você | nuvem |
| **Dados do jogo** (pasta `romfs`) | **você**, a partir do *seu* Hollow Knight de PC | seu PC (Linux/WSL) |

Os dados **não podem** ser gerados no GitHub: vêm do seu jogo (não se publica isso), a conversão leva horas e usa
vários GB. Por isso o fluxo é: converter no PC → compilar no GitHub → copiar os dois pro PS3.

Os dados são **os mesmos do 3DS** (sem recompilar nada em Python): o PS3 é big-endian, e o próprio jogo faz a troca
de ordem dos bytes ao ler (`source/endian.h`).

---

## Passo 1 — Compilar o programa no GitHub
1. Crie um repositório no GitHub e envie **todo o conteúdo do zip** (a pasta `.github/workflows/build.yml` precisa
   ir junto). **Não envie** a pasta `romfs`/`hkdata` (o `.gitignore` já bloqueia `romfs/`).
2. Abra a aba **Actions** → *Build PS3* → espere ficar verde (uns 5 a 10 min). Se não iniciou sozinho: **Run workflow**.
3. Dentro da execução, em **Artifacts**, baixe `hk3ds-ps3`. Contém:
   - `hk3ds_ps3.pkg` — versão **padrão**
   - `hk3ds_ps3_hd.pkg` — versão **HD** (arte em dobro de detalhe)
   - os `.self` equivalentes.

## Passo 2 — Converter os dados (no seu PC, uma vez)
Siga a seção "Build" do `README.md` (é o mesmo processo do 3DS), resumido:
```bash
sudo apt install git python3 python3-numpy python3-pil python3-yaml python3-cryptography ffmpeg
# exporte o jogo com o AssetRipper (README.md, "Export the game") para a pasta hkdata
tools/build.sh --check                 # confere os requisitos
tools/build.sh --no-compile --jobs 4   # só os dados -> pasta romfs/   (não precisa de devkitPro)
tools/build.sh --no-compile --hd       # opcional: pasta romfs_hd/ (para a versão HD)
python3 tools/ps3_check_romfs.py romfs # confere se a pasta está completa
```
(Windows: use o WSL2 com Ubuntu.) Leva bastante tempo e espaço, é normal.

## Passo 3 — Instalar no PS3
Precisa de PS3 com **CFW ou HEN** (para instalar `.pkg` não oficiais).

1. Copie `hk3ds_ps3.pkg` (ou `_hd`) para um pendrive/FTP e instale pelo XMB: *Jogo → Package Manager → Instalar*.
   Isso cria a pasta do jogo: `/dev_hdd0/game/HKNT00001/` (HD: `HKNT00002`).
2. Copie o **conteúdo** da sua pasta `romfs` (versão HD: o conteúdo de `romfs_hd`) para:
   ```
   /dev_hdd0/game/HKNT00001/USRDIR/romfs/      (HD: /dev_hdd0/game/HKNT00002/USRDIR/romfs/)
   ```
   (via FTP do multiMAN/webMAN, ou pendrive + gerenciador de arquivos). O arquivo
   `.../romfs/gfx/ui.spr` precisa existir. Dá para usar também `/dev_hdd0/HK3DS/romfs` ou `/HK3DS/romfs` num pendrive USB.
3. Abra o jogo no XMB. Se faltar dado, aparece uma tela explicando onde colocar.

Os **saves** ficam em `.../USRDIR/save/` (ao lado do `romfs`).

## Controles (posição dos botões = 3DS)
| 3DS | DualShock 3 |
|---|---|
| Circle Pad | Analógico esquerdo (ou direcional) |
| A (direita) | ○ |
| B (baixo) | ✕ (pular) |
| X (cima) | △ |
| Y (esquerda) | □ |
| L / R | L1 / R1 |
| ZL / ZR | L2 / R2 |
| START / SELECT | START / SELECT |
| — | **R3** (clicar o analógico direito): muda a tela de baixo |

Nos menus, **○ confirma e ✕ volta** (igual ao A/B do 3DS), ao contrário do padrão ocidental do PS3.

**Tela de baixo do 3DS** (mapa, inventário): R3 alterna entre *Auto* (aparece menor no canto quando o inventário está
aberto) → *Sempre no canto* → *Tela cheia* → *Oculta*. A tela de cima é desenhada em 720p (3× — 1200×720 centralizado).

## Problemas comuns
- **Tela de "game data not found"**: o `romfs` está na pasta errada ou faltando `gfx/ui.spr`.
- **Sem som**: o `save/log.txt` mostra se a porta de áudio abriu; sons ficam em `romfs/sfx` e `romfs/music`.
- **Fecha/trava ao entrar em áreas grandes**: tente a versão padrão em vez da HD (menos memória).
- **Erro no Actions**: veja o passo que falhou; o workflow baixa o toolchain `ps3dev` de
  `github.com/ps3dev/ps3toolchain/releases` (se a versão sumir, atualize a URL no `build.yml`).

## Compilar localmente (opcional)
Com o ps3dev instalado (`PS3DEV`/`PSL1GHT` definidos) e `nvidia-cg-toolkit` no Linux:
```bash
make -f Makefile.ps3 pkg          # padrão
make -f Makefile.ps3 HD=1 pkg     # HD
```
(Não use `-j`.)
