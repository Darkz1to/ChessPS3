// PS3 (PSL1GHT) stand-in for the libctru API that HK3DS uses. Same idea as host/3ds.h (the PC test build): the game
// code is compiled unchanged against this header, and ps3.c implements the functions on top of PSL1GHT
// (RSX video, DualShock 3 input, the audio port, PPU threads).
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/stat.h>
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
typedef int8_t s8; typedef int16_t s16; typedef int32_t s32; typedef int64_t s64;
typedef s32 Result; typedef u32 Handle;
#define R_SUCCEEDED(r) ((r) >= 0)
#define R_FAILED(r) ((r) < 0)
#define CUR_THREAD_HANDLE 0xFFFF8000
#define U64_MAX UINT64_MAX

// 3DS button bits. ps3.c fills them from the DualShock 3 by position: A=Circle (right), B=Cross (bottom),
// X=Triangle (top), Y=Square (left), L/R=L1/R1, ZL/ZR=L2/R2.
enum {
    KEY_A = 1 << 0, KEY_B = 1 << 1, KEY_SELECT = 1 << 2, KEY_START = 1 << 3, KEY_DRIGHT = 1 << 4, KEY_DLEFT = 1 << 5,
    KEY_DUP = 1 << 6, KEY_DDOWN = 1 << 7, KEY_R = 1 << 8, KEY_L = 1 << 9, KEY_X = 1 << 10, KEY_Y = 1 << 11,
    KEY_ZL = 1 << 14, KEY_ZR = 1 << 15,
};
typedef struct { s16 dx, dy; } circlePosition;
typedef enum { GFX_TOP = 0, GFX_BOTTOM = 1 } gfxScreen_t;
typedef enum { GFX_LEFT = 0, GFX_RIGHT = 1 } gfx3dSide_t;

void hidScanInput(void); u32 hidKeysDown(void); u32 hidKeysHeld(void); u32 hidKeysUp(void); void hidCircleRead(circlePosition *);
bool aptMainLoop(void);
void gfxInitDefault(void); void gfxSetWide(bool w); void gfxExit(void); void gspWaitForVBlank(void);
void *consoleInit(gfxScreen_t, void *);
Result romfsInit(void); Result romfsExit(void);
void osSetSpeedupEnable(bool); u64 osGetTime(void); u64 svcGetSystemTick(void);
Result svcGetThreadPriority(s32 *out, Handle h);
void *linearAlloc(size_t); void linearFree(void *);
size_t linearSpaceFree(void);
size_t envGetHeapSize(void); size_t envGetLinearHeapSize(void);
Result APT_CheckNew3DS(bool *out);
Result GSPGPU_FlushDataCache(const void *, u32); Result DSP_FlushDataCache(const void *, u32);
void svcSleepThread(s64 ns);

// ---- threads and locks (PPU threads, lwmutex, semaphore) ----
typedef struct { u64 impl[6]; } LightLock;        // sys_lwmutex_t (24 bytes) - see ps3.c
typedef struct { u64 sem; int ok; } LightEvent;   // a semaphore that holds at most one signal
enum { RESET_ONESHOT = 0 };
void LightLock_Init(LightLock *l); void LightLock_Lock(LightLock *l); void LightLock_Unlock(LightLock *l);
void LightEvent_Init(LightEvent *e, int t); void LightEvent_Signal(LightEvent *e); void LightEvent_Wait(LightEvent *e);
typedef void *Thread;
typedef void (*ThreadFunc)(void *);
Thread threadCreate(ThreadFunc f, void *arg, size_t stack, int prio, int core, bool detached);
Result threadJoin(Thread t, u64 timeout);
void threadFree(Thread t);

// ---- ndsp: a software mixer feeding the PS3 audio port (see ps3.c) ----
typedef enum { NDSP_WBUF_FREE = 0, NDSP_WBUF_QUEUED, NDSP_WBUF_PLAYING, NDSP_WBUF_DONE } ndspWbufStatus;
typedef struct ndspWaveBuf_s { union { s16 *data_pcm16; void *data_vaddr; }; u32 nsamples; void *adpcm; u32 offset; bool looping; u8 status; u16 sequence_id; struct ndspWaveBuf_s *next; } ndspWaveBuf;
enum { NDSP_OUTPUT_MONO = 0, NDSP_OUTPUT_STEREO = 1, NDSP_INTERP_POLYPHASE = 0, NDSP_INTERP_LINEAR = 1, NDSP_INTERP_NONE = 2,
       NDSP_FORMAT_MONO_PCM16 = 5, NDSP_FORMAT_STEREO_PCM16 = 10 };
Result ndspInit(void); void ndspExit(void); void ndspSetOutputMode(int m);
void ndspSetCallback(void (*cb)(void *), void *d);
void ndspChnReset(int c); void ndspChnSetInterp(int c, int i); void ndspChnSetRate(int c, float r); void ndspChnSetFormat(int c, int f);
void ndspChnSetMix(int c, float *m); void ndspChnWaveBufAdd(int c, ndspWaveBuf *b); void ndspChnWaveBufClear(int c); bool ndspChnIsPlaying(int c);

// ---- APT hooks (HOME menu / sleep): the PS3 has neither; the XMB quit is handled by aptMainLoop ----
typedef enum { APTHOOK_ONSUSPEND = 0, APTHOOK_ONRESTORE, APTHOOK_ONSLEEP, APTHOOK_ONWAKEUP, APTHOOK_ONEXIT, APTHOOK_COUNT } APT_HookType;
typedef void (*aptHookFn)(APT_HookType hook, void *param);
typedef struct tag_aptHookCookie { struct tag_aptHookCookie *next; aptHookFn callback; void *param; } aptHookCookie;
static inline void aptHook(aptHookCookie *c, aptHookFn fn, void *p) { (void)c; (void)fn; (void)p; }
static inline void aptUnhook(aptHookCookie *c) { (void)c; }

// ---- PS3 specific ----
void ps3_set_argv0(const char *argv0);          // where the game folder is (data and saves)
const char *ps3_data_mount(void);               // "romfs/" found: returns a description of where, else NULL
void ps3_message(const char *text);             // full-screen text; returns when the player presses START or quits
void ps3_ui_hint(bool bottomWanted);            // the bottom screen has something to show (the inventory)
FILE *ps3_fopen(const char *path, const char *mode);
int ps3_mkdir(const char *path, int mode);
int ps3_remove(const char *path);
int ps3_rename(const char *from, const char *to);
