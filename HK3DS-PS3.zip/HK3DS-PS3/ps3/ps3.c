// HK3DS on the PS3: implements the libctru / citro2d subset the game uses (ps3/3ds.h, ps3/citro2d.h) on PSL1GHT.
//   video : RSX (librsx), one textured-quad pipeline, 3DS screens laid out on a 1280x720 frame
//   input : DualShock 3 -> 3DS keys and circle pad
//   audio : ndsp emulation = software mixer on a PPU thread, output through the audio port (48 kHz stereo float)
//   files : romfs:/ and sdmc:/ paths -> folders on the PS3
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <malloc.h>
#include <ppu-types.h>
#include <sys/thread.h>
#include <sys/mutex.h>
#include <sys/sem.h>
#include <sys/systime.h>
#include <sys/process.h>
#include <sysutil/sysutil.h>
#include <sysutil/video.h>
#include <io/pad.h>
#include <audio/audio.h>
#include <rsx/rsx.h>
#include "3ds.h"
#include "citro2d.h"
#include "font8x16.h"
#include "hk_vpo.h"
#include "hk_fpo.h"

SYS_PROCESS_PARAM(1001, 0x200000);     // main thread: 2 MB of stack

int host_tintmode;       // gfx.c / citro2d.h
int host_additive;       // gfx.c

/* ============================== files ============================== */
static char g_base[256] = "/dev_hdd0/game/HKNT00001/USRDIR";
static char g_romfs[320], g_save[320];
static char g_desc[340];

void ps3_set_argv0(const char *a0) {
    if (a0 && a0[0] == '/') {
        snprintf(g_base, sizeof g_base, "%s", a0);
        char *s = strrchr(g_base, '/');
        if (s && s != g_base) *s = 0;
    }
}
static bool exists(const char *p) { FILE *f = fopen(p, "rb"); if (f) { fclose(f); return true; } return false; }

const char *ps3_data_mount(void) {
    static const char *abs[] = { "/dev_hdd0/game/HKNT00001/USRDIR", "/dev_hdd0/HK3DS", "/dev_usb000/HK3DS", "/dev_usb001/HK3DS", NULL };
    char cand[320], probe[360];
    for (int i = -1; ; i++) {
        const char *base = i < 0 ? g_base : abs[i];
        if (!base) break;
        snprintf(cand, sizeof cand, "%s/romfs", base);
        snprintf(probe, sizeof probe, "%s/gfx/ui.spr", cand);
        if (exists(probe)) {
            snprintf(g_romfs, sizeof g_romfs, "%s", cand);
            snprintf(g_save, sizeof g_save, "%s/save", base);
            mkdir(g_save, 0777);
            snprintf(g_desc, sizeof g_desc, "%s", cand);
            return g_desc;
        }
    }
    return NULL;
}
static void map_path(const char *p, char *out, size_t n) {
    if (!strncmp(p, "romfs:/", 7)) snprintf(out, n, "%s/%s", g_romfs, p + 7);
    else if (!strncmp(p, "sdmc:/3ds/hk3ds/", 16)) snprintf(out, n, "%s/%s", g_save, p + 16);
    else if (!strncmp(p, "sdmc:/", 6)) snprintf(out, n, "%s/%s", g_save, p + 6);
    else snprintf(out, n, "%s", p);
}
FILE *ps3_fopen(const char *path, const char *mode) { char b[512]; map_path(path, b, sizeof b); return fopen(b, mode); }
int ps3_mkdir(const char *path, int mode) {
    if (!strcmp(path, "sdmc:/3ds") || !strcmp(path, "sdmc:/3ds/hk3ds")) return 0;   // the save folder is made at start
    char b[512]; map_path(path, b, sizeof b); return mkdir(b, mode);
}
int ps3_remove(const char *path) { char b[512]; map_path(path, b, sizeof b); return remove(b); }
int ps3_rename(const char *a, const char *c) { char x[512], y[512]; map_path(a, x, sizeof x); map_path(c, y, sizeof y); return rename(x, y); }

/* ============================== time / misc ============================== */
static u64 t0us;
u64 osGetTime(void) { if (!t0us) t0us = sysGetSystemTime(); return (u64)(sysGetSystemTime() - t0us) / 1000; }
u64 svcGetSystemTick(void) { return (u64)(sysGetSystemTime() * 268.111856); }       // 3DS ARM11 ticks (268 MHz): used for timing only
void osSetSpeedupEnable(bool b) { (void)b; }
Result svcGetThreadPriority(s32 *o, Handle h) { (void)h; *o = 0x30; return 0; }
void svcSleepThread(s64 ns) { sysUsleep((u32)(ns / 1000)); }
void *linearAlloc(size_t n) { return memalign(64, n); }
void linearFree(void *p) { free(p); }
size_t linearSpaceFree(void) { return 128u << 20; }          // the room-tile and sound budgets key off this: "plenty"
size_t envGetHeapSize(void) { return 128u << 20; }
size_t envGetLinearHeapSize(void) { return 128u << 20; }
Result APT_CheckNew3DS(bool *o) { *o = true; return 0; }
Result romfsInit(void) { return 0; } Result romfsExit(void) { return 0; }
void *consoleInit(gfxScreen_t s, void *c) { (void)s; (void)c; return NULL; }
void gfxSetWide(bool w) { (void)w; }

/* ============================== threads ============================== */
typedef struct { sys_ppu_thread_t id; ThreadFunc f; void *arg; } PThread;
static void thread_tramp(void *a) { PThread *t = a; t->f(t->arg); sysThreadExit(0); }
Thread threadCreate(ThreadFunc f, void *arg, size_t stack, int prio, int core, bool detached) {
    (void)prio; (void)core; (void)detached;
    PThread *t = calloc(1, sizeof *t); if (!t) return NULL;
    t->f = f; t->arg = arg;
    if (stack < 0x40000) stack = 0x40000;
    if (sysThreadCreate(&t->id, thread_tramp, t, 900, stack, THREAD_JOINABLE, "hk") != 0) { free(t); return NULL; }
    return t;
}
Result threadJoin(Thread th, u64 timeout) { (void)timeout; PThread *t = th; u64 r; if (t) sysThreadJoin(t->id, &r); return 0; }
void threadFree(Thread th) { free(th); }

void LightLock_Init(LightLock *l) {
    sys_lwmutex_attr_t a; memset(&a, 0, sizeof a);
    a.attr_protocol = SYS_LWMUTEX_PROTOCOL_FIFO; a.attr_recursive = SYS_LWMUTEX_ATTR_NOT_RECURSIVE;
    memcpy(a.name, "hklk", 4);
    sysLwMutexCreate((sys_lwmutex_t *)l, &a);
}
void LightLock_Lock(LightLock *l) { sysLwMutexLock((sys_lwmutex_t *)l, 0); }
void LightLock_Unlock(LightLock *l) { sysLwMutexUnlock((sys_lwmutex_t *)l); }
void LightEvent_Init(LightEvent *e, int t) {
    (void)t;
    sys_sem_attr_t a; memset(&a, 0, sizeof a);
    a.attr_protocol = SYS_SEM_ATTR_PROTOCOL; a.attr_pshared = SYS_SEM_ATTR_PSHARED; memcpy(a.name, "hkev", 4);
    sys_sem_t s = 0; e->ok = sysSemCreate(&s, &a, 0, 1) == 0; e->sem = s;
}
void LightEvent_Signal(LightEvent *e) { if (e->ok) sysSemPost((sys_sem_t)e->sem, 1); }
void LightEvent_Wait(LightEvent *e) { if (e->ok) sysSemWait((sys_sem_t)e->sem, 0); }

/* ============================== input ============================== */
static bool g_quit;
static void sysutil_cb(u64 status, u64 param, void *ud) { (void)param; (void)ud; if (status == SYSUTIL_EXIT_GAME) g_quit = true; }
static u32 keysNow, keysPrev; static circlePosition cpos;
static int bottomMode;          // 0 auto, 1 inset, 2 bottom full screen, 3 hidden  (R3 cycles)
static bool r3Prev;

void hidScanInput(void) {
    sysUtilCheckCallback();
    keysPrev = keysNow; keysNow = 0; cpos.dx = cpos.dy = 0;
    padInfo pi; padData pd;
    if (ioPadGetInfo(&pi) != 0) return;
    for (int p = 0; p < MAX_PADS; p++) {
        if (!pi.status[p]) continue;
        if (ioPadGetData(p, &pd) != 0 || pd.len <= 0) continue;
        u32 k = 0;
        if (pd.BTN_CIRCLE) k |= KEY_A;   if (pd.BTN_CROSS) k |= KEY_B;
        if (pd.BTN_TRIANGLE) k |= KEY_X; if (pd.BTN_SQUARE) k |= KEY_Y;
        if (pd.BTN_L1) k |= KEY_L;       if (pd.BTN_R1) k |= KEY_R;
        if (pd.BTN_L2) k |= KEY_ZL;      if (pd.BTN_R2) k |= KEY_ZR;
        if (pd.BTN_START) k |= KEY_START; if (pd.BTN_SELECT) k |= KEY_SELECT;
        if (pd.BTN_UP) k |= KEY_DUP;     if (pd.BTN_DOWN) k |= KEY_DDOWN;
        if (pd.BTN_LEFT) k |= KEY_DLEFT; if (pd.BTN_RIGHT) k |= KEY_DRIGHT;
        keysNow |= k;
        int ax = (int)pd.ANA_L_H - 128, ay = 128 - (int)pd.ANA_L_V;       // 0..255, y down -> circle pad +-156, y up
        if (abs(ax) < 24) ax = 0; if (abs(ay) < 24) ay = 0;                // dead zone
        ax = ax * 156 / 128; ay = ay * 156 / 128;
        if (abs(ax) > abs(cpos.dx)) cpos.dx = (s16)ax;
        if (abs(ay) > abs(cpos.dy)) cpos.dy = (s16)ay;
        if (pd.BTN_R3 && !r3Prev) bottomMode = (bottomMode + 1) & 3;
        r3Prev = pd.BTN_R3;
        break;                                                              // pad 1 only
    }
}
u32 hidKeysDown(void) { return keysNow & ~keysPrev; }
u32 hidKeysHeld(void) { return keysNow; }
u32 hidKeysUp(void) { return keysPrev & ~keysNow; }
void hidCircleRead(circlePosition *c) { *c = cpos; }
bool aptMainLoop(void) { sysUtilCheckCallback(); return !g_quit; }

/* ============================== RSX video ============================== */
#define CB_SIZE        0x100000
#define HOST_SIZE      (32 * 1024 * 1024)
#define LABEL_FRAME    250
#define LABEL_SYNC     251
#define MAX_VERTS      (4 * 20000)          // per frame
typedef struct { float x, y, z, u, v, r, g, b, a, tb, tm, pad; } Vtx;     // 48 bytes

static gcmContextData *ctx;
static u32 dw, dh, fbPitch, fbOff[2], depthOff, depthPitch;
static void *fbMem[2], *depthMem;
static int curFb;
static u32 frameNo = 1, syncVal;
static Vtx *vbuf[2]; static u32 vbufOff[2]; static int vcount, vfirst;
static rsxVertexProgram *vpo = (rsxVertexProgram *)hk_vpo;
static rsxFragmentProgram *fpo = (rsxFragmentProgram *)hk_fpo;
static void *vpUcode, *fpMem; static u32 fpOff;
static rsxProgramAttrib *aPos, *aCol, *aTex, *aTint, *aSamp;
static C3D_Tex whiteTex;
static C3D_RenderTarget targets[2] = { { 0 }, { 1 } };
// layout: where each 3DS screen lands in the frame
static struct { bool vis; float s, ox, oy, w, h; } scr[2];
static int curScr;
static bool uiWantBottom, firstFlip = true;
static C3D_Tex *batchTex; static int batchAdd;

static void gpu_wait_label(u8 idx, u32 val) { while (*(vu32 *)gcmGetLabelAddress(idx) < val) usleep(30); }
static void gpu_sync_now(void) {
    ++syncVal;
    rsxSetWriteBackendLabel(ctx, LABEL_SYNC, syncVal);
    rsxFlushBuffer(ctx);
    while (*(vu32 *)gcmGetLabelAddress(LABEL_SYNC) != syncVal) usleep(30);
}

// ---- deferred texture frees (the GPU may still read last frame's textures)
typedef struct { void *p; u32 frame; } Pend;
static Pend pend[512]; static int npend;
static void rsx_free_later(void *p) {
    if (!p) return;
    if (npend >= 512) { gpu_sync_now(); for (int i = 0; i < npend; i++) rsxFree(pend[i].p); npend = 0; }
    pend[npend].p = p; pend[npend++].frame = frameNo;
}
static void rsx_free_ready(void) {
    u32 done = *(vu32 *)gcmGetLabelAddress(LABEL_FRAME);
    int j = 0;
    for (int i = 0; i < npend; i++) { if (pend[i].frame <= done) rsxFree(pend[i].p); else pend[j++] = pend[i]; }
    npend = j;
}

// ---- textures
// The CPU copy is allocated with a small header in front of it, so a data pointer (what the game passes to
// GSPGPU_FlushDataCache) leads back to its texture.
typedef struct { u64 magic; C3D_Tex *owner; } TexHdr;
#define TEX_MAGIC 0x484B335444535458ull
static int bpp_of(GPU_TEXCOLOR f) { return f == GPU_RGBA8 ? 4 : f == GPU_RGB8 ? 3 : f == GPU_A8 ? 1 : 2; }
static u32 rsx_fmt_of(GPU_TEXCOLOR f) {
    switch (f) { case GPU_RGB565: return GCM_TEXTURE_FORMAT_R5G6B5; case GPU_RGBA4: return GCM_TEXTURE_FORMAT_A4R4G4B4;
                 case GPU_RGBA5551: return GCM_TEXTURE_FORMAT_A1R5G5B5; default: return GCM_TEXTURE_FORMAT_A8R8G8B8; }
}
static bool rsx_alloc(C3D_Tex *t) {
    int bpp = (t->fmt == GPU_RGBA8 || t->fmt == GPU_RGB8 || t->fmt == GPU_A8) ? 4 : 2;
    t->rsxFmt = rsx_fmt_of(t->fmt);
    t->rsxPitch = (t->width * bpp + 63) & ~63u;
    u32 sz = t->rsxPitch * t->height;
    t->rsx = rsxMemalign(128, sz);
    if (!t->rsx) return false;
    rsxAddressToOffset(t->rsx, &t->rsxOffset);
    return true;
}
bool C3D_TexInit(C3D_Tex *t, u16 w, u16 h, GPU_TEXCOLOR f) {
    memset(t, 0, sizeof *t);
    t->width = w; t->height = h; t->fmt = f; t->size = w * h * bpp_of(f);
    TexHdr *hd = calloc(1, sizeof(TexHdr) + t->size);
    if (!hd) return false;
    hd->magic = TEX_MAGIC; hd->owner = t; t->data = (char *)hd + sizeof(TexHdr);
    if (!rsx_alloc(t)) { free(hd); t->data = NULL; return false; }
    return true;
}
void C3D_TexDelete(C3D_Tex *t) {
    if (!t->staticDone && t->data) { TexHdr *h = (TexHdr *)((char *)t->data - sizeof(TexHdr)); h->magic = 0; free(h); }
    t->data = NULL;
    if (t->rsx) rsx_free_later(t->rsx);
    t->rsx = NULL;
}
void C3D_TexSetFilter(C3D_Tex *t, int a, int b) { (void)b; t->linear = a == GPU_LINEAR; }

static inline int morton(int x, int y) { return (x & 1) | ((y & 1) << 1) | ((x & 2) << 1) | ((y & 2) << 2) | ((x & 4) << 2) | ((y & 4) << 3); }
// 3DS layout (8x8 tiles, Morton order inside, memory row 0 = image top) -> RSX linear rows
static void convert(C3D_Tex *t) {
    const int w = t->width, h = t->height, tw8 = w >> 3;
    const u8 *d8 = t->data; const u16 *d16 = t->data;
    for (int y = 0; y < h; y++) {
        u8 *row = (u8 *)t->rsx + (size_t)y * t->rsxPitch;
        for (int x = 0; x < w; x++) {
            int idx = ((y >> 3) * tw8 + (x >> 3)) * 64 + morton(x & 7, y & 7);
            switch (t->fmt) {
                case GPU_RGBA8: { const u8 *p = d8 + idx * 4; u8 *o = row + x * 4; o[0] = p[0]; o[1] = p[3]; o[2] = p[2]; o[3] = p[1]; break; }   // A B G R -> A R G B
                case GPU_RGB8:  { const u8 *p = d8 + idx * 3; u8 *o = row + x * 4; o[0] = 255; o[1] = p[2]; o[2] = p[1]; o[3] = p[0]; break; }
                case GPU_A8:    { u8 *o = row + x * 4; o[0] = d8[idx]; o[1] = o[2] = o[3] = 0; break; }
                case GPU_RGBA4: { u16 v = d16[idx]; ((u16 *)row)[x] = (u16)(((v & 0xF) << 12) | ((v >> 4) & 0xFFF)); break; }       // RGBA4 -> ARGB4
                case GPU_RGBA5551: { u16 v = d16[idx]; ((u16 *)row)[x] = (u16)(((v & 1) << 15) | ((v >> 1) & 0x7FFF)); break; }     // RGBA5551 -> A1RGB5
                default: { u16 v = d16[idx]; ((u16 *)row)[x] = v; break; }                                                            // RGB565 as is
            }
        }
    }
}
// The CPU copy is allocated with a small header in front of it, so a data pointer (what the game passes to
// GSPGPU_FlushDataCache) leads back to its texture.
static void tex_commit(C3D_Tex *t) {
    if (!t->rsx || !t->data || t->staticDone) return;
    if (t->lastFrame > *(vu32 *)gcmGetLabelAddress(LABEL_FRAME)) {      // the GPU may still be reading it (drawn last frame)
        if (t->lastFrame < frameNo) gpu_wait_label(LABEL_FRAME, t->lastFrame); else gpu_sync_now();
    }
    convert(t);
}
Result GSPGPU_FlushDataCache(const void *p, u32 n) {
    (void)n;
    const TexHdr *h = (const TexHdr *)((const char *)p - sizeof(TexHdr));
    if (h->magic == TEX_MAGIC && h->owner && h->owner->data == p) tex_commit(h->owner);
    return 0;
}
Result DSP_FlushDataCache(const void *p, u32 n) { (void)p; (void)n; return 0; }
void C3D_TexStaticDone(C3D_Tex *t) {
    if (!t->rsx || !t->data || t->staticDone) return;
    TexHdr *h = (TexHdr *)((char *)t->data - sizeof(TexHdr)); h->magic = 0;
    free(h); t->data = t->rsx; t->staticDone = 1;                         // data stays non-NULL: "allocated"
}

/* ---- video init (modelled on PSL1GHT's rsxtest sample) ---- */
static void set_render_target(int i) {
    gcmSurface sf; memset(&sf, 0, sizeof sf);
    sf.colorFormat = GCM_SURFACE_X8R8G8B8; sf.colorTarget = GCM_SURFACE_TARGET_0;
    sf.colorLocation[0] = GCM_LOCATION_RSX; sf.colorOffset[0] = fbOff[i]; sf.colorPitch[0] = fbPitch;
    sf.colorLocation[1] = sf.colorLocation[2] = sf.colorLocation[3] = GCM_LOCATION_RSX;
    sf.colorOffset[1] = sf.colorOffset[2] = sf.colorOffset[3] = 0;
    sf.colorPitch[1] = sf.colorPitch[2] = sf.colorPitch[3] = 64;
    sf.depthFormat = GCM_SURFACE_ZETA_Z24S8; sf.depthLocation = GCM_LOCATION_RSX; sf.depthOffset = depthOff; sf.depthPitch = depthPitch;
    sf.type = GCM_SURFACE_TYPE_LINEAR; sf.antiAlias = GCM_SURFACE_CENTER_1;
    sf.width = dw; sf.height = dh; sf.x = 0; sf.y = 0;
    rsxSetSurface(ctx, &sf);
}

static void video_init(void) {
    void *host = memalign(1024 * 1024, HOST_SIZE);
    rsxInit(&ctx, CB_SIZE, HOST_SIZE, host);
    static const u32 ids[] = { VIDEO_RESOLUTION_720, VIDEO_RESOLUTION_1080, VIDEO_RESOLUTION_480, VIDEO_RESOLUTION_576 };
    videoResolution res; int resId = 0, rv = -1;
    for (unsigned i = 0; i < sizeof ids / sizeof *ids; i++) {
        if (videoGetResolutionAvailability(VIDEO_PRIMARY, ids[i], VIDEO_ASPECT_AUTO, 0) != 1) continue;
        resId = ids[i]; rv = videoGetResolution(resId, &res);
        if (!rv) break;
    }
    if (rv) exit(1);
    videoConfiguration cfg = { (u8)resId, VIDEO_BUFFER_FORMAT_XRGB, VIDEO_ASPECT_AUTO, { 0, 0, 0, 0, 0, 0, 0, 0, 0 }, (u32)res.width * 4 };
    if (videoConfigure(VIDEO_PRIMARY, &cfg, NULL, 0)) exit(1);
    dw = res.width; dh = res.height;
    gcmSetFlipMode(GCM_FLIP_VSYNC);
    fbPitch = dw * 4; depthPitch = dw * 4;
    for (int i = 0; i < 2; i++) {
        fbMem[i] = rsxMemalign(64, dh * fbPitch);
        rsxAddressToOffset(fbMem[i], &fbOff[i]);
        gcmSetDisplayBuffer(i, fbOff[i], fbPitch, dw, dh);
        memset(fbMem[i], 0, dh * fbPitch);
    }
    depthMem = rsxMemalign(64, dh * depthPitch);
    rsxAddressToOffset(depthMem, &depthOff);
    *(vu32 *)gcmGetLabelAddress(LABEL_FRAME) = 0; *(vu32 *)gcmGetLabelAddress(LABEL_SYNC) = 0;

    u32 sz;
    rsxVertexProgramGetUCode(vpo, &vpUcode, &sz);
    void *fpU; rsxFragmentProgramGetUCode(fpo, &fpU, &sz);
    fpMem = rsxMemalign(64, sz); memcpy(fpMem, fpU, sz); rsxAddressToOffset(fpMem, &fpOff);
    aPos = rsxVertexProgramGetAttrib(vpo, "position"); aCol = rsxVertexProgramGetAttrib(vpo, "color");
    aTex = rsxVertexProgramGetAttrib(vpo, "texcoord"); aTint = rsxVertexProgramGetAttrib(vpo, "tint");
    aSamp = rsxFragmentProgramGetAttrib(fpo, "texture");
    for (int i = 0; i < 2; i++) { vbuf[i] = rsxMemalign(128, MAX_VERTS * sizeof(Vtx)); rsxAddressToOffset(vbuf[i], &vbufOff[i]); }
    set_render_target(0);
    C3D_TexInit(&whiteTex, 8, 8, GPU_RGBA8);
    memset(whiteTex.data, 0xFF, whiteTex.size); GSPGPU_FlushDataCache(whiteTex.data, whiteTex.size);
    C3D_TexSetFilter(&whiteTex, GPU_NEAREST, GPU_NEAREST);
}

void gfxInitDefault(void) {
    sysUtilRegisterCallback(0, sysutil_cb, NULL);
    ioPadInit(7);
    video_init();
}
void gfxExit(void) { if (ctx) gpu_sync_now(); }
void gspWaitForVBlank(void) { }

/* ---- the 2D batcher ---- */
static int curBlendAdd = -1, vsel;
static void bind_tex(C3D_Tex *t) {
    gcmTexture tx; memset(&tx, 0, sizeof tx);
    tx.format = t->rsxFmt | GCM_TEXTURE_FORMAT_LIN;
    tx.mipmap = 1; tx.dimension = GCM_TEXTURE_DIMS_2D; tx.cubemap = GCM_FALSE;
    tx.remap = ((GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_B_SHIFT) | (GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_G_SHIFT) |
                (GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_R_SHIFT) | (GCM_TEXTURE_REMAP_TYPE_REMAP << GCM_TEXTURE_REMAP_TYPE_A_SHIFT) |
                (GCM_TEXTURE_REMAP_COLOR_B << GCM_TEXTURE_REMAP_COLOR_B_SHIFT) | (GCM_TEXTURE_REMAP_COLOR_G << GCM_TEXTURE_REMAP_COLOR_G_SHIFT) |
                (GCM_TEXTURE_REMAP_COLOR_R << GCM_TEXTURE_REMAP_COLOR_R_SHIFT) | (GCM_TEXTURE_REMAP_COLOR_A << GCM_TEXTURE_REMAP_COLOR_A_SHIFT));
    tx.width = t->width; tx.height = t->height; tx.depth = 1; tx.location = GCM_LOCATION_RSX; tx.pitch = t->rsxPitch; tx.offset = t->rsxOffset;
    u8 u = aSamp->index;
    rsxLoadTexture(ctx, u, &tx);
    rsxTextureControl(ctx, u, GCM_TRUE, 0 << 8, 12 << 8, GCM_TEXTURE_MAX_ANISO_1);
    u8 f = t->linear ? GCM_TEXTURE_LINEAR : GCM_TEXTURE_NEAREST;
    rsxTextureFilter(ctx, u, 0, f, f, GCM_TEXTURE_CONVOLUTION_QUINCUNX);
    rsxTextureWrapMode(ctx, u, GCM_TEXTURE_CLAMP_TO_EDGE, GCM_TEXTURE_CLAMP_TO_EDGE, GCM_TEXTURE_CLAMP_TO_EDGE, 0, GCM_TEXTURE_ZFUNC_LESS, 0);
}
static void flush_batch(void) {
    if (vcount == vfirst || !batchTex) { vfirst = vcount; return; }
    if (curBlendAdd != batchAdd) {
        if (batchAdd) rsxSetBlendFunc(ctx, GCM_SRC_ALPHA, GCM_ONE, GCM_SRC_ALPHA, GCM_ONE);
        else rsxSetBlendFunc(ctx, GCM_SRC_ALPHA, GCM_ONE_MINUS_SRC_ALPHA, GCM_SRC_ALPHA, GCM_ONE_MINUS_SRC_ALPHA);
        curBlendAdd = batchAdd;
    }
    rsxInvalidateTextureCache(ctx, GCM_INVALIDATE_TEXTURE);
    bind_tex(batchTex);
    rsxDrawVertexArray(ctx, GCM_TYPE_QUADS, vfirst, vcount - vfirst);
    vfirst = vcount;
}
static void quad(C3D_Tex *t, const float *px, const float *py, const float *u, const float *v, const float (*col)[4], const float *tb, float tm) {
    if (!scr[curScr].vis || !t || !t->rsx || vcount + 4 > MAX_VERTS) return;
    if (t != batchTex || host_additive != batchAdd) { flush_batch(); batchTex = t; batchAdd = host_additive; }
    t->lastFrame = frameNo;
    const float s = scr[curScr].s, ox = scr[curScr].ox, oy = scr[curScr].oy;
    Vtx *o = vbuf[vsel] + vcount;
    for (int i = 0; i < 4; i++, o++) {
        o->x = (ox + px[i] * s) / dw * 2.0f - 1.0f; o->y = 1.0f - (oy + py[i] * s) / dh * 2.0f; o->z = 0;
        o->u = u[i]; o->v = v[i];
        o->r = col[i][0]; o->g = col[i][1]; o->b = col[i][2]; o->a = col[i][3];
        o->tb = tb[i]; o->tm = tm; o->pad = 0;
    }
    vcount += 4;
}
static void c32f(u32 c, float o[4]) { o[0] = (c & 255) / 255.f; o[1] = (c >> 8 & 255) / 255.f; o[2] = (c >> 16 & 255) / 255.f; o[3] = (c >> 24) / 255.f; }
// the sub-texture corner (fx, fy in 0..1 across the drawn quad) -> texture coordinates; v is flipped because the
// 3DS keeps v = 1 at memory row 0 (the top of the image) and RSX has v = 0 there
static void sub_uv(const Tex3DS_SubTexture *s, float fx, float fy, float *u, float *v) {
    float uu, vv;
    if (s->top < s->bottom) { uu = s->top + (s->bottom - s->top) * fy; vv = s->left + (s->right - s->left) * fx; }
    else { uu = s->left + (s->right - s->left) * fx; vv = s->top + (s->bottom - s->top) * fy; }
    *u = uu; *v = 1.0f - vv;
}
static void tint_cols(const C2D_ImageTint *tint, float col[4][4], float tb[4]) {
    static const int map[4] = { 0, 1, 3, 2 };            // quad order TL TR BR BL -> citro2d corners TL TR BL BR
    for (int i = 0; i < 4; i++) {
        if (tint) { c32f(tint->corners[map[i]].color, col[i]); tb[i] = tint->corners[map[i]].blend; }
        else { col[i][0] = col[i][1] = col[i][2] = col[i][3] = 1; tb[i] = 0; }
    }
}
static const float FX[4] = { 0, 1, 1, 0 }, FY[4] = { 0, 0, 1, 1 };

bool C2D_DrawImageAt(C2D_Image img, float x, float y, float depth, const C2D_ImageTint *tint, float sx, float sy) {
    (void)depth;
    const Tex3DS_SubTexture *s = img.subtex;
    float w = s->width * sx, h = s->height * sy, aw = fabsf(w), ah = fabsf(h);
    float px[4], py[4], u[4], v[4], col[4][4], tb[4];
    for (int i = 0; i < 4; i++) {
        px[i] = x + FX[i] * aw; py[i] = y + FY[i] * ah;
        sub_uv(s, w < 0 ? 1 - FX[i] : FX[i], h < 0 ? 1 - FY[i] : FY[i], &u[i], &v[i]);
    }
    tint_cols(tint, col, tb);
    quad(img.tex, px, py, u, v, (const float (*)[4])col, tb, host_tintmode == C2D_TintMult ? 1.0f : 0.0f);
    return true;
}
bool C2D_DrawImage(C2D_Image img, const C2D_DrawParams *pr, const C2D_ImageTint *tint) {
    const Tex3DS_SubTexture *s = img.subtex;
    float w = fabsf(pr->pos.w), h = fabsf(pr->pos.h);
    if (w <= 0 || h <= 0) return true;
    float cs = cosf(pr->angle), sn = sinf(pr->angle);
    float px[4], py[4], u[4], v[4], col[4][4], tb[4];
    for (int i = 0; i < 4; i++) {
        float lx = -pr->center.x + FX[i] * w, ly = -pr->center.y + FY[i] * h;
        px[i] = lx * cs - ly * sn + pr->pos.x; py[i] = lx * sn + ly * cs + pr->pos.y;
        sub_uv(s, pr->pos.w < 0 ? 1 - FX[i] : FX[i], pr->pos.h < 0 ? 1 - FY[i] : FY[i], &u[i], &v[i]);
    }
    tint_cols(tint, col, tb);
    quad(img.tex, px, py, u, v, (const float (*)[4])col, tb, host_tintmode == C2D_TintMult ? 1.0f : 0.0f);
    return true;
}
bool C2D_DrawRectSolid(float x, float y, float z, float w, float h, u32 clr) {
    (void)z;
    if ((clr >> 24) == 0) return true;
    float px[4] = { x, x + w, x + w, x }, py[4] = { y, y, y + h, y + h }, u[4] = { .5f, .5f, .5f, .5f }, v[4] = { .5f, .5f, .5f, .5f }, col[4][4], tb[4] = { 1, 1, 1, 1 };
    for (int i = 0; i < 4; i++) c32f(clr, col[i]);
    quad(&whiteTex, px, py, u, v, (const float (*)[4])col, tb, 1.0f);
    return true;
}
bool C2D_DrawTriangle(float x0, float y0, u32 c0, float x1, float y1, u32 c1, float x2, float y2, u32 c2, float depth) {
    (void)depth;
    float px[4] = { x0, x1, x2, x2 }, py[4] = { y0, y1, y2, y2 }, u[4] = { .5f, .5f, .5f, .5f }, v[4] = { .5f, .5f, .5f, .5f }, col[4][4], tb[4] = { 1, 1, 1, 1 };
    c32f(c0, col[0]); c32f(c1, col[1]); c32f(c2, col[2]); c32f(c2, col[3]);
    quad(&whiteTex, px, py, u, v, (const float (*)[4])col, tb, 1.0f);
    return true;
}

/* ---- screens and frames ---- */
void ps3_ui_hint(bool w) { uiWantBottom = w; }
C3D_RenderTarget *C2D_CreateScreenTarget(gfxScreen_t s, gfx3dSide_t side) { (void)side; return &targets[s]; }
static void layout(void) {
    float S = fminf(dw / 400.0f, dh / 240.0f);
    scr[0].vis = bottomMode != 2; scr[0].s = S; scr[0].w = 400; scr[0].h = 240;
    scr[0].ox = floorf((dw - 400 * S) / 2); scr[0].oy = floorf((dh - 240 * S) / 2);
    float bs = S; bool bv = true;
    switch (bottomMode) { case 0: bv = uiWantBottom; bs = S * 0.5f; break; case 1: bs = S * 0.4f; break; case 2: bs = S; break; default: bv = false; }
    scr[1].vis = bv; scr[1].s = bs; scr[1].w = 320; scr[1].h = 240;
    if (bottomMode == 2) { scr[1].ox = floorf((dw - 320 * bs) / 2); scr[1].oy = floorf((dh - 240 * bs) / 2); }
    else { scr[1].ox = floorf(dw - 320 * bs - 12); scr[1].oy = floorf(dh - 240 * bs - 12); }
}
static void set_scene(int i) {
    flush_batch(); curScr = i;
    float x = scr[i].ox, y = scr[i].oy, w = scr[i].w * scr[i].s, h = scr[i].h * scr[i].s;
    if (x < 0) { w += x; x = 0; } if (y < 0) { h += y; y = 0; }
    if (x + w > dw) w = dw - x; if (y + h > dh) h = dh - y;
    if (w < 1) w = 1; if (h < 1) h = 1;
    rsxSetScissor(ctx, (u16)x, (u16)y, (u16)w, (u16)h);
}
void C2D_SceneBegin(C3D_RenderTarget *t) { set_scene(t->screen); }
void C2D_TargetClear(C3D_RenderTarget *t, u32 c) {
    set_scene(t->screen);
    c |= 0xFF000000u;
    // opaque fill of the whole screen area (drawn as a quad, so the inset's own region only)
    float px[4] = { 0, scr[curScr].w, scr[curScr].w, 0 }, py[4] = { 0, 0, scr[curScr].h, scr[curScr].h }, u[4] = { .5f, .5f, .5f, .5f }, v[4] = { .5f, .5f, .5f, .5f }, col[4][4], tb[4] = { 1, 1, 1, 1 };
    for (int i = 0; i < 4; i++) c32f(c, col[i]);
    quad(&whiteTex, px, py, u, v, (const float (*)[4])col, tb, 1.0f);
}
void C3D_FrameBegin(int f) {
    (void)f;
    rsx_free_ready();
    layout();
    // draw environment (as the sample's setDrawEnv)
    rsxSetColorMask(ctx, GCM_COLOR_MASK_B | GCM_COLOR_MASK_G | GCM_COLOR_MASK_R | GCM_COLOR_MASK_A);
    rsxSetColorMaskMrt(ctx, 0);
    f32 scale[4] = { dw * 0.5f, dh * -0.5f, 0.5f, 0.0f }, offset[4] = { dw * 0.5f, dh * 0.5f, 0.5f, 0.0f };
    rsxSetViewport(ctx, 0, 0, dw, dh, 0.0f, 1.0f, scale, offset);
    rsxSetScissor(ctx, 0, 0, dw, dh);
    for (int i = 0; i < 8; i++) rsxSetViewportClip(ctx, i, dw, dh);
    rsxSetDepthTestEnable(ctx, GCM_FALSE); rsxSetDepthWriteEnable(ctx, GCM_FALSE);
    rsxSetCullFaceEnable(ctx, GCM_FALSE);
    rsxSetShadeModel(ctx, GCM_SHADE_MODEL_SMOOTH);
    rsxSetBlendEquation(ctx, GCM_FUNC_ADD, GCM_FUNC_ADD);
    rsxSetBlendEnable(ctx, GCM_TRUE); rsxSetLogicOpEnable(ctx, GCM_FALSE);
    curBlendAdd = -1;
    rsxSetClearColor(ctx, 0xFF000000u);
    rsxClearSurface(ctx, GCM_CLEAR_R | GCM_CLEAR_G | GCM_CLEAR_B | GCM_CLEAR_A);
    rsxLoadVertexProgram(ctx, vpo, vpUcode);
    rsxLoadFragmentProgramLocation(ctx, fpo, fpOff, GCM_LOCATION_RSX);
    rsxInvalidateVertexCache(ctx);
    u32 base = vbufOff[vsel];
    rsxBindVertexArrayAttrib(ctx, aPos->index, 0, base + 0, sizeof(Vtx), 3, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    rsxBindVertexArrayAttrib(ctx, aTex->index, 0, base + 12, sizeof(Vtx), 2, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    rsxBindVertexArrayAttrib(ctx, aCol->index, 0, base + 20, sizeof(Vtx), 4, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    rsxBindVertexArrayAttrib(ctx, aTint->index, 0, base + 36, sizeof(Vtx), 2, GCM_VERTEX_DATA_TYPE_F32, GCM_LOCATION_RSX);
    vcount = vfirst = 0; batchTex = NULL; batchAdd = 0; curScr = 0;
}
void C3D_FrameEnd(int f) {
    (void)f;
    flush_batch();
    rsxSetWriteBackendLabel(ctx, LABEL_FRAME, frameNo);
    if (!firstFlip) { while (gcmGetFlipStatus() != 0) usleep(200); }
    gcmResetFlipStatus();
    gcmSetFlip(ctx, curFb);
    rsxFlushBuffer(ctx);
    gcmSetWaitFlip(ctx);
    curFb ^= 1; set_render_target(curFb);
    firstFlip = false; frameNo++; vsel ^= 1;
}

/* ---- full-screen text (data missing, errors) ---- */
void ps3_message(const char *text) {
    static C3D_Tex font; static bool ok;
    if (!ok) {
        if (!C3D_TexInit(&font, 128, 96, GPU_A8)) return;
        u8 *d = font.data;
        for (int g = 0; g < 95; g++) for (int y = 0; y < 16; y++) for (int x = 0; x < 8; x++) {
            int px = (g % 16) * 8 + x, py = (g / 16) * 16 + y;
            d[((py >> 3) * 16 + (px >> 3)) * 64 + morton(px & 7, py & 7)] = (ps3_font8x16[g * 16 + y] & (0x80 >> x)) ? 255 : 0;
        }
        GSPGPU_FlushDataCache(font.data, font.size); C3D_TexSetFilter(&font, GPU_NEAREST, GPU_NEAREST); ok = true;
    }
    C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    while (aptMainLoop()) {
        hidScanInput();
        if (hidKeysDown() & KEY_START) break;
        C3D_FrameBegin(0);
        C2D_TargetClear(top, C2D_Color32(20, 20, 28, 255));
        C2D_SceneBegin(top);
        float x = 12, y = 14;
        for (const char *p = text; *p; p++) {
            if (*p == '\n') { x = 12; y += 17; continue; }
            int g = (unsigned char)*p - 32; if (g < 0 || g > 94) g = 0;
            float px[4] = { x, x + 8, x + 8, x }, py[4] = { y, y, y + 16, y + 16 };
            float u0 = (g % 16) * 8 / 128.0f, u1 = u0 + 8 / 128.0f, v0 = (g / 16) * 16 / 96.0f, v1 = v0 + 16 / 96.0f;
            float u[4] = { u0, u1, u1, u0 }, v[4] = { 1 - v0, 1 - v0, 1 - v1, 1 - v1 };   // sub_uv's flip: callers pass 3DS-style v; here direct RSX v
            for (int i = 0; i < 4; i++) v[i] = (i < 2) ? v0 : v1;
            float col[4][4]; for (int i = 0; i < 4; i++) { col[i][0] = col[i][1] = col[i][2] = 0.92f; col[i][3] = 1; }
            float tb[4] = { 1, 1, 1, 1 };
            quad(&font, px, py, u, v, (const float (*)[4])col, tb, 0.0f);
            x += 8;
        }
        C3D_FrameEnd(0);
    }
}

/* ============================== ndsp: software mixer on the audio port ============================== */
#define NCH 32
typedef struct { ndspWaveBuf *head, *tail; double pos; float rate; int fmt; float mixL, mixR; } Chan;
static Chan chn[NCH];
static LightLock ndspLock; static bool ndspUp; static volatile bool mixRun;
static void (*ndspCb)(void *); static void *ndspCbData;
static Thread mixThread;

static void chan_clear(Chan *c) {
    for (ndspWaveBuf *b = c->head; b; ) { ndspWaveBuf *n = b->next; b->status = NDSP_WBUF_DONE; b = n; }
    c->head = c->tail = NULL; c->pos = 0;
}
void ndspChnReset(int i) { if (!ndspUp || i < 0 || i >= NCH) return; LightLock_Lock(&ndspLock); chan_clear(&chn[i]); chn[i].rate = 32728; chn[i].fmt = NDSP_FORMAT_MONO_PCM16; chn[i].mixL = chn[i].mixR = 0; LightLock_Unlock(&ndspLock); }
void ndspChnSetInterp(int c, int i) { (void)c; (void)i; }
void ndspChnSetRate(int i, float r) { if (ndspUp && i >= 0 && i < NCH) chn[i].rate = r; }
void ndspChnSetFormat(int i, int f) { if (ndspUp && i >= 0 && i < NCH) chn[i].fmt = f; }
void ndspChnSetMix(int i, float *m) { if (ndspUp && i >= 0 && i < NCH) { chn[i].mixL = m[0]; chn[i].mixR = m[1]; } }
void ndspChnWaveBufAdd(int i, ndspWaveBuf *b) {
    if (!ndspUp || i < 0 || i >= NCH) return;
    LightLock_Lock(&ndspLock);
    b->next = NULL; b->status = NDSP_WBUF_QUEUED;
    Chan *c = &chn[i];
    if (c->tail) c->tail->next = b; else { c->head = b; c->pos = 0; }
    c->tail = b;
    LightLock_Unlock(&ndspLock);
}
void ndspChnWaveBufClear(int i) { if (!ndspUp || i < 0 || i >= NCH) return; LightLock_Lock(&ndspLock); chan_clear(&chn[i]); LightLock_Unlock(&ndspLock); }
bool ndspChnIsPlaying(int i) { return ndspUp && i >= 0 && i < NCH && chn[i].head != NULL; }
void ndspSetOutputMode(int m) { (void)m; }
void ndspSetCallback(void (*cb)(void *), void *d) { ndspCb = cb; ndspCbData = d; }

static void mix_block(float *out) {
    float acc[AUDIO_BLOCK_SAMPLES * 2]; memset(acc, 0, sizeof acc);
    LightLock_Lock(&ndspLock);
    for (int ci = 0; ci < NCH; ci++) {
        Chan *c = &chn[ci];
        if (!c->head) continue;
        const double step = c->rate / 48000.0;
        const bool st = c->fmt == NDSP_FORMAT_STEREO_PCM16;
        for (int i = 0; i < AUDIO_BLOCK_SAMPLES; i++) {
            ndspWaveBuf *b = c->head;
            if (!b) break;
            if (b->status == NDSP_WBUF_QUEUED) b->status = NDSP_WBUF_PLAYING;
            const u32 n = b->nsamples; const s16 *d = b->data_pcm16;
            if (!n || !d) { b->status = NDSP_WBUF_DONE; c->head = b->next; if (!c->head) c->tail = NULL; c->pos = 0; i--; continue; }
            u32 ip = (u32)c->pos; float fr = (float)(c->pos - ip);
            u32 jp = ip + 1; if (jp >= n) jp = b->looping ? 0 : ip;
            float l, r;
            if (st) { l = d[ip * 2] + (d[jp * 2] - d[ip * 2]) * fr; r = d[ip * 2 + 1] + (d[jp * 2 + 1] - d[ip * 2 + 1]) * fr; }
            else { l = r = d[ip] + (d[jp] - d[ip]) * fr; }
            acc[i * 2] += l * c->mixL; acc[i * 2 + 1] += r * c->mixR;
            c->pos += step;
            if (c->pos >= n) {
                if (b->looping) c->pos -= n;
                else { b->status = NDSP_WBUF_DONE; c->head = b->next; if (!c->head) c->tail = NULL; c->pos = 0; }
            }
        }
    }
    LightLock_Unlock(&ndspLock);
    for (int i = 0; i < AUDIO_BLOCK_SAMPLES * 2; i++) { float v = acc[i] * (1.0f / 32768.0f); out[i] = v > 1 ? 1 : v < -1 ? -1 : v; }
}
static void mixer_main(void *arg) {
    (void)arg;
    audioPortParam ap; memset(&ap, 0, sizeof ap);
    ap.numChannels = AUDIO_PORT_2CH; ap.numBlocks = AUDIO_BLOCK_8; ap.attrib = 0; ap.level = 1.0f;
    u32 port; audioPortConfig cfg;
    if (audioInit() != 0 || audioPortOpen(&ap, &port) != 0 || audioGetPortConfig(port, &cfg) != 0) { ndspUp = false; return; }
    audioPortStart(port);
    volatile u64 *readIdx = (volatile u64 *)(u64)cfg.readIndex;
    float *base = (float *)(u64)cfg.audioDataStart;
    u32 wr = 1;
    while (mixRun) {
        u32 cur = (u32)(*readIdx) % AUDIO_BLOCK_8;
        u32 ahead = (wr + AUDIO_BLOCK_8 - cur) % AUDIO_BLOCK_8;
        if (ahead == 0) { wr = (cur + 2) % AUDIO_BLOCK_8; continue; }          // overrun: resync
        if (ahead >= 4) { sysUsleep(1000); continue; }                        // enough queued (about 20 ms)
        mix_block(base + 2 * AUDIO_BLOCK_SAMPLES * wr);
        wr = (wr + 1) % AUDIO_BLOCK_8;
        if (ndspCb) ndspCb(ndspCbData);
    }
    audioPortStop(port); audioPortClose(port); audioQuit();
}
Result ndspInit(void) {
    memset(chn, 0, sizeof chn);
    LightLock_Init(&ndspLock);
    ndspUp = true; mixRun = true;
    mixThread = threadCreate(mixer_main, NULL, 0x40000, 0, 0, false);
    if (!mixThread) { ndspUp = false; return -1; }
    sysUsleep(100000);                       // the mixer thread clears ndspUp if the audio port can't be opened
    return ndspUp ? 0 : -1;
}
void ndspExit(void) {
    if (!mixThread) return;
    mixRun = false; threadJoin(mixThread, 0); threadFree(mixThread); mixThread = NULL; ndspUp = false;
}
