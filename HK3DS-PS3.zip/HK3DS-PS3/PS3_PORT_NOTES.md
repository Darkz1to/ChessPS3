# PS3 port: what changed

Game logic (hero.c, fsm.c, ...) is untouched. The port is a shim, like `host/` (the PC test build):

| Piece | Where |
|---|---|
| libctru / citro2d API on PSL1GHT | `ps3/3ds.h`, `ps3/citro2d.h`, `ps3/ps3.c` (the game compiles against `-Ips3`) |
| Video: RSX textured quads, one vertex + one fragment shader (citro2d tint done per pixel) | `ps3/ps3.c`, `ps3/shaders/hk.{vcg,fcg}` |
| 3DS textures (8x8 Morton tiles, LE texels) -> RSX linear textures, converted on `GSPGPU_FlushDataCache` | `ps3/ps3.c` `convert()` |
| Input: DualShock 3 -> 3DS keys / circle pad | `ps3/ps3.c` `hidScanInput` |
| Audio: `ndsp*` emulated by a software mixer (48 kHz float, 8 blocks) on a PPU thread | `ps3/ps3.c`; `audio.c` unchanged except the .pcm byte swap |
| Endianness: reads of the little-endian data files go through `HK_LE` / `hk_swap16_array` | `source/endian.h`, `gfx.c`, `room.c`, `audio.c` |
| Paths `romfs:/`, `sdmc:/3ds/hk3ds/` -> game folder | `ps3/ps3.c`, `hkfile.h`, `patch.c` |
| Screens: top 400x240 at 3x on 720p; bottom screen as an inset (R3 cycles) | `ps3/ps3.c` `layout()` |

Choice on endianness: the data files stay little-endian (same files as the 3DS) and the loader swaps, so the Python
tools are unchanged. Verified: `HK_LE`/array swap and the zlib decoder under qemu-ppc64 (big-endian).

Small edits in game files (all guarded by `__PS3__`): `main.c` (paths, missing-data screen, bottom-screen hint),
`heaps.c`, `room.c` (no worker thread), `gfx.c` (`C3D_TexStaticDone`, swaps), `audio.c` (SFX budget, swap).

Memory: textures live in RSX memory (16-bit formats stay 16-bit); the CPU copy of sprite pages is freed after upload.
Not tested on hardware: performance, the RSX state setup, audio underruns, and memory on the HD build.
