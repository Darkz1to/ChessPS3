#pragma once
// Byte order of the converted game data.
// The tools/*.py converters write little-endian files (the 3DS and the PC are little-endian). The PS3's Cell/PowerPC
// is big-endian, so the loaders read through these helpers: on a little-endian machine they compile to nothing.
#include <stdint.h>
#include <string.h>

#if defined(__PS3__) || (defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
#define HK_BIG_ENDIAN 1
#endif

#ifdef HK_BIG_ENDIAN
static inline uint16_t hk_swap16(uint16_t v) { return __builtin_bswap16(v); }
static inline uint32_t hk_swap32(uint32_t v) { return __builtin_bswap32(v); }
// any 1/2/4-byte scalar (u8, s16, u16, u32, float...) read from a little-endian file
#define HK_LE(v) ({ __typeof__(v) _x = (v);                                                              \
    if (sizeof(_x) == 2) { uint16_t _t; memcpy(&_t, &_x, 2); _t = __builtin_bswap16(_t); memcpy(&_x, &_t, 2); } \
    else if (sizeof(_x) == 4) { uint32_t _t; memcpy(&_t, &_x, 4); _t = __builtin_bswap32(_t); memcpy(&_x, &_t, 4); } \
    _x; })
// a whole array of little-endian 16-bit texels / samples, in place
static inline void hk_swap16_array(void *p, size_t n) { uint16_t *a = (uint16_t *)p; for (size_t i = 0; i < n; i++) a[i] = __builtin_bswap16(a[i]); }
#else
static inline uint16_t hk_swap16(uint16_t v) { return v; }
static inline uint32_t hk_swap32(uint32_t v) { return v; }
#define HK_LE(v) (v)
static inline void hk_swap16_array(void *p, size_t n) { (void)p; (void)n; }
#endif
