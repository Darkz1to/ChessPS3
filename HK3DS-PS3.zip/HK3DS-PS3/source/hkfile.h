#pragma once
// Force-included into every source file (Makefile: -include hkfile.h) so each fopen of a romfs:/ file can be
// served from a data patch on the SD card (patch.c). The PC test build does the same in host_fopen.
// PS3: romfs:/ and sdmc:/ paths are mapped to the game folder (ps3/ps3.c).
#include <stdio.h>
#include <sys/stat.h>
#ifdef __PS3__
FILE *hk_fopen(const char *path, const char *mode);
int ps3_mkdir(const char *path, int mode);
int ps3_remove(const char *path);
int ps3_rename(const char *from, const char *to);
#define fopen hk_fopen
#define mkdir ps3_mkdir
#define remove ps3_remove
#define rename ps3_rename
#elif !defined(__HOST__)
FILE *hk_fopen(const char *path, const char *mode);
#define fopen hk_fopen
#endif
