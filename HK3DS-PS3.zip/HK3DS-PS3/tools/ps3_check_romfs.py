#!/usr/bin/env python3
"""Checks a converted romfs folder before you copy it to the PS3.
Usage: python3 tools/ps3_check_romfs.py [romfs]      (default: ./romfs)
The folder is the same one the 3DS build uses; the PS3 build reads it as it is (byte order is handled in the game)."""
import os, sys

root = sys.argv[1] if len(sys.argv) > 1 else "romfs"
if not os.path.isdir(root):
    sys.exit(f"'{root}' is not a folder. Run tools/build.sh --no-compile first (README.md), then pass the romfs folder.")
bad = 0
total = 0
print(f"Checking {os.path.abspath(root)}")
for d in ("gfx", "rooms", "text", "music", "sfx"):
    p = os.path.join(root, d)
    n = size = 0
    for dp, _, fs in os.walk(p):
        for f in fs:
            n += 1; size += os.path.getsize(os.path.join(dp, f))
    total += size
    ok = n > 0
    if d in ("gfx", "rooms", "text") and not ok: bad += 1
    print(f"  {'ok     ' if ok else ('MISSING' if d in ('gfx','rooms','text') else 'empty  ')} {d + '/':8} {n:6} files {size / 1048576:8.1f} MB")
ui = os.path.join(root, "gfx", "ui.spr")
if not os.path.isfile(ui):
    print("  MISSING gfx/ui.spr  (the game looks for this file to find its data)"); bad += 1
# the files are little-endian on purpose: just make sure they are not empty / truncated
for dp, _, fs in os.walk(root):
    for f in fs:
        p = os.path.join(dp, f)
        if os.path.getsize(p) == 0:
            print("  EMPTY FILE:", os.path.relpath(p, root)); bad += 1
print(f"Total {total / 1048576:.0f} MB")
if bad:
    print("PROBLEMS FOUND: fix the conversion before copying."); sys.exit(1)
print("Looks complete. Copy THIS folder's contents to the PS3 (see PS3_TUTORIAL.md).")
